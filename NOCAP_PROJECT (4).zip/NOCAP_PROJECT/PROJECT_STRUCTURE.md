# NoCap — Project Structure & Build Plan

**Stack:** HTML / CSS / JavaScript · Java (Spring Boot) · MySQL
**Scope:** exactly the 20 screens designed — nothing extra.

---

## 1. Full Directory Tree

```
NoCap/
│
├── frontend/
│   ├── index.html                    → Screen 01  Login (role switcher)
│   ├── signup.html                   → Screen 02  Customer sign up
│   ├── home.html                     → Screen 03  Restaurant list
│   ├── restaurant.html               → Screen 04  Details + menu
│   ├── checkout.html                 → Screen 05  Cart + checkout
│   ├── tracking.html                 → Screen 06  Order tracking
│   ├── orders.html                   → Screen 07  My orders + review
│   ├── profile.html                  → Screen 08  Profile
│   │
│   ├── restaurant/
│   │   ├── register.html             → Screen 09  Restaurant sign up
│   │   ├── dashboard.html            → Screen 10  Owner dashboard
│   │   ├── verification.html         → Screen 11  Verification status
│   │   ├── menu.html                 → Screen 12  Manage menu
│   │   ├── orders.html               → Screen 13  Manage orders
│   │   └── hygiene.html              → Screen 14  Hygiene photo upload
│   │
│   ├── admin/
│   │   ├── login.html                → Screen 15  Admin login
│   │   ├── dashboard.html            → Screen 16  Admin dashboard
│   │   ├── verification.html         → Screen 17  Verification queue
│   │   ├── verify-detail.html        → Screen 18  4-stage detail
│   │   ├── hygiene.html              → Screen 19  Hygiene monitoring
│   │   └── reviews.html              → Screen 20  Fake review detection
│   │
│   ├── css/
│   │   ├── style.css                 Base: colors, cards, buttons, badges
│   │   ├── customer.css              Customer-only layout
│   │   └── dashboard.css             Shared by restaurant + admin
│   │
│   ├── js/
│   │   ├── api.js                    fetch() wrapper + base URL
│   │   ├── auth.js                   login, logout, role redirect
│   │   ├── customer.js               home, menu, cart, checkout, orders
│   │   ├── restaurant.js             owner dashboard, menu, orders, hygiene
│   │   └── admin.js                  verification, hygiene, review moderation
│   │
│   └── assets/
│       └── images/
│
├── backend/
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/nocap/
│       │   ├── NoCapApplication.java
│       │   │
│       │   ├── model/                (10 entity classes)
│       │   │   ├── User.java             id, name, email, password, phone, role
│       │   │   ├── Restaurant.java       name, address, cuisine, status, hygieneScore
│       │   │   ├── Document.java         restaurantId, type, filePath, status
│       │   │   ├── Inspection.java       4 category scores, total, officerNote
│       │   │   ├── HygieneCheck.java     requestedAt, uploadedAt, score, passed
│       │   │   ├── MenuItem.java         restaurantId, name, price, available
│       │   │   ├── Order.java            customerId, restaurantId, total, status
│       │   │   ├── OrderItem.java        orderId, menuItemId, qty, price
│       │   │   ├── Review.java           orderId, rating, comment, status
│       │   │   └── ReviewFlag.java       reviewId, confidence, signals
│       │   │
│       │   ├── repository/           (10 interfaces, ~3 lines each)
│       │   │   └── UserRepository.java … ReviewFlagRepository.java
│       │   │
│       │   ├── service/              (5 classes — the real logic)
│       │   │   ├── AuthService.java          signup, login, role check
│       │   │   ├── OrderService.java         place order, status updates
│       │   │   ├── VerificationService.java  4-stage flow, approve/reject
│       │   │   ├── HygieneService.java       photo check, 3-fail suspend
│       │   │   └── ReviewCheckService.java   fake review scoring
│       │   │
│       │   ├── controller/           (4 classes — grouped by role)
│       │   │   ├── AuthController.java       /api/auth/**
│       │   │   ├── CustomerController.java   /api/customer/**
│       │   │   ├── RestaurantController.java /api/restaurant/**
│       │   │   └── AdminController.java      /api/admin/**
│       │   │
│       │   └── config/
│       │       └── WebConfig.java    CORS so frontend can call the API
│       │
│       └── resources/
│           ├── application.properties     MySQL URL, user, password
│           └── uploads/                   kitchen photos, documents
│
├── database/
│   ├── schema.sql                    11 tables (CREATE statements)
│   └── seed.sql                      test data: 3 restaurants, 1 admin, menu items
│
└── README.md
```

---

## 2. Database Tables (11)

| Table | Holds | Feeds screens |
|---|---|---|
| `users` | all three roles, `role` column decides | 01, 02, 08, 09, 15 |
| `restaurants` | name, address, status, hygiene_score | 03, 04, 10 |
| `documents` | trade licence, chef cert, NID + status | 11, 17, 18 |
| `inspections` | 4 category scores + officer note | 11, 18 |
| `hygiene_checks` | request time, upload time, pass/fail | 14, 19 |
| `menu_items` | name, price, available | 04, 12 |
| `orders` | customer, restaurant, total, status | 05, 06, 07, 13 |
| `order_items` | line items per order | 05, 13 |
| `reviews` | rating, comment, **order_id (required)** | 07 |
| `review_flags` | confidence + which signals fired | 20 |
| `admin_actions` | audit log of every admin decision | — |

`reviews.order_id` is `NOT NULL` with a foreign key. That single constraint is your strongest anti-fake-review defence — the database itself refuses a review with no order behind it.

---

## 3. Build Order — 6 Parts

Each part is independently testable. Finish one before starting the next.

### Part 1 — Database + Project Setup
- `schema.sql` (11 tables) and `seed.sql`
- Spring Boot project + `application.properties` MySQL connection
- All 10 model classes + 10 repository interfaces
- **Test:** app starts, tables visible in MySQL Workbench

### Part 2 — Auth (all 3 roles)
- `AuthService` + `AuthController` — signup, login, role-based redirect
- Screens 01, 02, 09, 15
- **Test:** three logins land on three different dashboards

### Part 3 — Restaurant Verification
- `VerificationService` + document upload
- Screens 11 (owner view), 17 and 18 (admin queue + approve/reject)
- Rule: restaurant stays hidden from customers until `status = 'APPROVED'`
- **Test:** register a restaurant, approve it as admin, see it appear on customer home

### Part 4 — Menu + Ordering
- `OrderService`
- Screens 03, 04, 05, 06, 12, 13
- **Test:** owner adds an item → customer orders it → owner accepts → status changes

### Part 5 — Hygiene System
- `HygieneService` — photo upload, pass/fail, 3-consecutive-fail auto-suspend
- Screens 14 (owner upload), 19 (admin monitoring)
- **Test:** fail three checks, restaurant auto-suspends and disappears from customer home

### Part 6 — Reviews + Fake Detection
- `ReviewCheckService`
- Screens 07 (write review), 20 (admin moderation)
- **Test:** try reviewing a cancelled order (blocked), post a generic review from a new account (flagged)

---

## 4. Fake Review Scoring — Keep It Simple

All four signals are plain SQL over your own tables. No ML library needed.

| Signal | Check | Weight |
|---|---|---|
| No linked order | `order_id` missing or not `DELIVERED` | 40 |
| Generic text | comment length < 20 chars | 25 |
| Duplicate pattern | same comment text exists elsewhere | 20 |
| New account | user created < 24 hours ago | 15 |

Sum the weights that fire. **Score > 70 → insert into `review_flags`** and hide the review pending admin decision. Nothing is auto-deleted.

`ReviewCheckService` for this is roughly 40 lines. That's the whole feature.

---

## 5. Keeping The Code Short

- **4 controllers, not 20.** Group endpoints by role.
- **~28 API endpoints total.** Auth 3, Customer 9, Restaurant 8, Admin 8.
- **Reuse `style.css` everywhere.** The 20 HTML files share the same cards, badges, and buttons — the design set already uses one stylesheet, so copy those classes once.
- **No JS framework.** Plain `fetch()` in `api.js`, everything else calls it.
- **Skip:** JWT (use simple session or localStorage for a course project), file storage services (save uploads to a local folder), real payment gateway (Cash on Delivery + a mock bKash button).

Rough total: **~1,800 lines of Java**, **~900 lines of JS**, **~600 lines of CSS**. Very manageable for a two-person team.

---

Tell me which part to start and I'll write that part's code — files complete, in build order.
