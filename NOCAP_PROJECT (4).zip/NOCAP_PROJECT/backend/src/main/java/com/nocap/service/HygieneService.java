package com.nocap.service;

/* HygieneService — Build in: Part 5

   Methods:
   - requestCheck(restaurantId) — creates a HygieneCheck row with requestedAt
   - submitPhoto(checkId, file, score) — sets uploadedAt, passed = score >= 75
   - checkAutoSuspend(restaurantId) — if last 3 checks all failed, set status SUSPENDED
   - a check with no upload within 15 minutes counts as a fail
*/

// TODO: @Service class
