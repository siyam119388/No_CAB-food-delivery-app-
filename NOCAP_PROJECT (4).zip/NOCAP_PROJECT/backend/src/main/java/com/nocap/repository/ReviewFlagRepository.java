package com.nocap.repository;

import com.nocap.model.ReviewFlag;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReviewFlagRepository extends JpaRepository<ReviewFlag, Long> {

    List<ReviewFlag> findByDecision(ReviewFlag.Decision decision);

    Optional<ReviewFlag> findByReviewId(Long reviewId);
}
