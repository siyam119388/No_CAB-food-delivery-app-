package com.nocap.repository;

import com.nocap.model.Inspection;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InspectionRepository extends JpaRepository<Inspection, Long> {

    Optional<Inspection> findTopByRestaurantIdOrderByInspectedAtDesc(Long restaurantId);
}
