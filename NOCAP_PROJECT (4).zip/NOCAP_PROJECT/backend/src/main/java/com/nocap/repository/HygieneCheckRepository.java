package com.nocap.repository;

import com.nocap.model.HygieneCheck;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HygieneCheckRepository extends JpaRepository<HygieneCheck, Long> {

    /** Newest first — Part 5 reads the top 3 to test for auto suspension. */
    List<HygieneCheck> findByRestaurantIdOrderByRequestedAtDesc(Long restaurantId);
}
