package com.nocap.service;

/* OrderService — Build in: Part 4

   Methods:
   - placeOrder(customerId, restaurantId, items) — save order + order items, status PLACED
   - updateStatus(orderId, newStatus) — owner accepts, prepares, marks ready
   - getCustomerOrders(customerId) / getRestaurantOrders(restaurantId)
*/

// TODO: @Service class
