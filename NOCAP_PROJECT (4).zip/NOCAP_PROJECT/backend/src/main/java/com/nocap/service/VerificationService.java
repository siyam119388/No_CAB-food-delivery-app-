package com.nocap.service;

/* VerificationService — Build in: Part 3

   Methods:
   - uploadDocument(restaurantId, type, file) — stage 1
   - saveInspection(restaurantId, four scores, note) — stage 3, totalScore = sum
   - approve(restaurantId) — status APPROVED, restaurant becomes visible to customers
   - reject(restaurantId, reason) — status REJECTED
*/

// TODO: @Service class
