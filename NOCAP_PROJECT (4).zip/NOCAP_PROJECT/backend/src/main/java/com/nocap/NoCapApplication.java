package com.nocap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
public class NoCapApplication {

    public static void main(String[] args) {
        SpringApplication.run(NoCapApplication.class, args);
        System.out.println("\n  NoCap API running on http://localhost:8080\n");
    }

    /** Used by AuthService in Part 2 to hash and check passwords. */
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
