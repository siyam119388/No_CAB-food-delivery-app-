package com.nocap.repository;

import com.nocap.model.Restaurant;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RestaurantRepository extends JpaRepository<Restaurant, Long> {

    /** Customer home screen — only approved restaurants. */
    List<Restaurant> findByStatus(Restaurant.Status status);

    Optional<Restaurant> findByOwnerId(Long ownerId);

    long countByStatus(Restaurant.Status status);
}
