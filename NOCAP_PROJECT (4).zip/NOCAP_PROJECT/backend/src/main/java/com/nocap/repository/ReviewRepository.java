package com.nocap.repository;

import com.nocap.model.Review;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByRestaurantIdAndStatus(Long restaurantId, Review.Status status);

    /** One review per order — Part 6 checks this before saving. */
    boolean existsByOrderId(Long orderId);

    /** Duplicate text signal in the fake review scoring. */
    long countByComment(String comment);
}
