package com.nocap.service;

/* ReviewCheckService — Build in: Part 6

   Methods:
   - submitReview(orderId, rating, comment) — reject unless order status is DELIVERED
   - scoreReview(review) — sum the weights of the signals that fire:
   -     no linked / undelivered order .... 40
   -     comment length < 20 chars ........ 25
   -     duplicate comment text ........... 20
   -     account younger than 24 hours .... 15
   - if score > 70 -> save ReviewFlag and hide the review pending admin decision
   - nothing is ever auto deleted — admin decides on screen 20
*/

// TODO: @Service class
