package com.nocap.service;

/* AuthService — Build in: Part 2

   Methods:
   - signup(User user) — hash password, save, return user
   - login(email, password) — verify, return user with role
   - registerRestaurant(...) — creates owner user + restaurant with status PENDING
*/

// TODO: @Service class
