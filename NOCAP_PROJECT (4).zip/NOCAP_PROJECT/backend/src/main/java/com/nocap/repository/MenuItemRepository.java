package com.nocap.repository;

import com.nocap.model.MenuItem;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MenuItemRepository extends JpaRepository<MenuItem, Long> {

    List<MenuItem> findByRestaurantId(Long restaurantId);

    /** Customer menu screen hides sold out items. */
    List<MenuItem> findByRestaurantIdAndAvailableTrue(Long restaurantId);
}
