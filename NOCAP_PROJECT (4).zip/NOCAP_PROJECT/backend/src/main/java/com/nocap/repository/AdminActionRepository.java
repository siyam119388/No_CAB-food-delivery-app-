package com.nocap.repository;

import com.nocap.model.AdminAction;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminActionRepository extends JpaRepository<AdminAction, Long> {

    List<AdminAction> findTop20ByOrderByCreatedAtDesc();
}
