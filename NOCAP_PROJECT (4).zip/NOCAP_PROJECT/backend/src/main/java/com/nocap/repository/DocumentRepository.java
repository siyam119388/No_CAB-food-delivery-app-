package com.nocap.repository;

import com.nocap.model.Document;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentRepository extends JpaRepository<Document, Long> {

    List<Document> findByRestaurantId(Long restaurantId);
}
