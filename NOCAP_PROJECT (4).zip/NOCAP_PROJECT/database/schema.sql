-- ============================================================
--  NoCap — Database Schema (11 tables)
--  Part 1
--  Run this first:  mysql -u root -p < schema.sql
-- ============================================================

DROP DATABASE IF EXISTS nocap;
CREATE DATABASE nocap CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nocap;

-- ------------------------------------------------------------
-- 1. users  —  all three roles live in one table
-- ------------------------------------------------------------
CREATE TABLE users (
    id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100)  NOT NULL,
    email      VARCHAR(120)  NOT NULL UNIQUE,
    password   VARCHAR(120)  NOT NULL,
    phone      VARCHAR(20),
    address    VARCHAR(255),
    role       ENUM('CUSTOMER','RESTAURANT_OWNER','ADMIN') NOT NULL DEFAULT 'CUSTOMER',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- 2. restaurants  —  only APPROVED ones are visible to customers
-- ------------------------------------------------------------
CREATE TABLE restaurants (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    owner_id      BIGINT NOT NULL,
    name          VARCHAR(120) NOT NULL,
    address       VARCHAR(255),
    cuisine       VARCHAR(60),
    delivery_fee  DECIMAL(8,2) DEFAULT 50.00,
    status        ENUM('PENDING','APPROVED','REJECTED','SUSPENDED') NOT NULL DEFAULT 'PENDING',
    hygiene_score INT DEFAULT 0,
    rating        DECIMAL(3,2) DEFAULT 0.00,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_id) REFERENCES users(id)
);

-- ------------------------------------------------------------
-- 3. documents  —  verification stage 1
-- ------------------------------------------------------------
CREATE TABLE documents (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    restaurant_id BIGINT NOT NULL,
    type          ENUM('TRADE_LICENCE','CHEF_CERT','OWNER_NID') NOT NULL,
    file_path     VARCHAR(255),
    status        ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
    uploaded_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id)
);

-- ------------------------------------------------------------
-- 4. inspections  —  verification stage 3, four categories x 25
-- ------------------------------------------------------------
CREATE TABLE inspections (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    restaurant_id BIGINT NOT NULL,
    cleanliness   INT NOT NULL,
    storage       INT NOT NULL,
    staff_hygiene INT NOT NULL,
    waste_control INT NOT NULL,
    total_score   INT NOT NULL,
    officer_name  VARCHAR(100),
    officer_note  TEXT,
    inspected_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id)
);

-- ------------------------------------------------------------
-- 5. hygiene_checks  —  random photo checks after approval
--    3 consecutive passed = FALSE  ->  auto suspend
-- ------------------------------------------------------------
CREATE TABLE hygiene_checks (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    restaurant_id BIGINT NOT NULL,
    requested_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    uploaded_at   DATETIME NULL,
    photo_path    VARCHAR(255),
    score         INT DEFAULT 0,
    passed        BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id)
);

-- ------------------------------------------------------------
-- 6. menu_items
-- ------------------------------------------------------------
CREATE TABLE menu_items (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    restaurant_id BIGINT NOT NULL,
    name          VARCHAR(120) NOT NULL,
    description   VARCHAR(255),
    price         DECIMAL(8,2) NOT NULL,
    category      VARCHAR(60),
    available     BOOLEAN NOT NULL DEFAULT TRUE,
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id)
);

-- ------------------------------------------------------------
-- 7. orders
-- ------------------------------------------------------------
CREATE TABLE orders (
    id             BIGINT AUTO_INCREMENT PRIMARY KEY,
    customer_id    BIGINT NOT NULL,
    restaurant_id  BIGINT NOT NULL,
    subtotal       DECIMAL(10,2) NOT NULL,
    delivery_fee   DECIMAL(8,2)  NOT NULL,
    total          DECIMAL(10,2) NOT NULL,
    payment_method ENUM('COD','BKASH') NOT NULL DEFAULT 'COD',
    address        VARCHAR(255),
    status         ENUM('PLACED','ACCEPTED','PREPARING','OUT_FOR_DELIVERY','DELIVERED','CANCELLED')
                   NOT NULL DEFAULT 'PLACED',
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id)   REFERENCES users(id),
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id)
);

-- ------------------------------------------------------------
-- 8. order_items
-- ------------------------------------------------------------
CREATE TABLE order_items (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id     BIGINT NOT NULL,
    menu_item_id BIGINT NOT NULL,
    quantity     INT NOT NULL,
    price        DECIMAL(8,2) NOT NULL,
    FOREIGN KEY (order_id)     REFERENCES orders(id),
    FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
);

-- ------------------------------------------------------------
-- 9. reviews
--    order_id is NOT NULL and UNIQUE. This one constraint is the
--    strongest anti fake review rule in the project: the database
--    itself refuses a review with no real order behind it, and
--    allows only one review per order.
-- ------------------------------------------------------------
CREATE TABLE reviews (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id      BIGINT NOT NULL UNIQUE,
    customer_id   BIGINT NOT NULL,
    restaurant_id BIGINT NOT NULL,
    rating        INT NOT NULL,
    comment       VARCHAR(500),
    status        ENUM('VISIBLE','HIDDEN','REMOVED') NOT NULL DEFAULT 'VISIBLE',
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id)      REFERENCES orders(id),
    FOREIGN KEY (customer_id)   REFERENCES users(id),
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id)
);

-- ------------------------------------------------------------
-- 10. review_flags  —  fake review detection results
-- ------------------------------------------------------------
CREATE TABLE review_flags (
    id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    review_id  BIGINT NOT NULL,
    confidence INT NOT NULL,
    signals    VARCHAR(255),
    decision   ENUM('PENDING','KEPT','REMOVED') NOT NULL DEFAULT 'PENDING',
    decided_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (review_id)  REFERENCES reviews(id),
    FOREIGN KEY (decided_by) REFERENCES users(id)
);

-- ------------------------------------------------------------
-- 11. admin_actions  —  audit log
-- ------------------------------------------------------------
CREATE TABLE admin_actions (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    admin_id    BIGINT NOT NULL,
    action      VARCHAR(60) NOT NULL,
    target_type VARCHAR(40),
    target_id   BIGINT,
    note        VARCHAR(255),
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users(id)
);

-- ------------------------------------------------------------
-- Indexes for the queries the screens actually run
-- ------------------------------------------------------------
CREATE INDEX idx_restaurant_status ON restaurants(status);
CREATE INDEX idx_menu_restaurant   ON menu_items(restaurant_id);
CREATE INDEX idx_order_customer    ON orders(customer_id);
CREATE INDEX idx_order_restaurant  ON orders(restaurant_id);
CREATE INDEX idx_review_restaurant ON reviews(restaurant_id);
CREATE INDEX idx_hygiene_rest      ON hygiene_checks(restaurant_id);

SELECT 'NoCap schema created — 11 tables' AS status;
