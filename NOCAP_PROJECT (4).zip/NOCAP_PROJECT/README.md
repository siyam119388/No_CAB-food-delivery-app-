# NoCap

Verified & hygiene-assured food delivery.
*No fake reviews. No dirty kitchens.*

**Stack:** HTML / CSS / JavaScript · Java (Spring Boot) · MySQL

---

## Two Core Features

**1. Restaurant Verification** — a restaurant is invisible to customers until it
passes four stages: documents, owner identity, kitchen inspection, admin approval.
After approval it joins a random kitchen-photo cycle; three consecutive failed
checks suspend it automatically.

**2. Fake Review Detection** — a review must be linked to a delivered order
(enforced by the database itself). Reviews that pass that check are scored on
four signals; above 70 they are flagged for an admin, never auto-deleted.

---

## Three User Types

| Role | Entry point | Screens |
|---|---|---|
| Customer | `frontend/index.html` | 8 |
| Restaurant Owner | `frontend/restaurant/dashboard.html` | 6 |
| Admin | `frontend/admin/login.html` | 6 |

One `users` table with a `role` column drives all three — see `js/auth.js`.

---

## Setup

1. `mysql -u root -p < database/schema.sql`
2. `mysql -u root -p < database/seed.sql`
3. Set your MySQL password in `backend/src/main/resources/application.properties`
4. `cd backend && mvn spring-boot:run` — API on `http://localhost:8080`
5. Open `frontend/index.html` (VS Code Live Server works well)

---

## Build Order

Every file in this project has a `Build in: Part N` comment at the top.
Work through the parts in order — each one is testable on its own.

| Part | What | Test when done |
|---|---|---|
| 1 | Database, models, repositories, project setup | App starts, 11 tables visible |
| 2 | Auth for all three roles | Three logins reach three dashboards |
| 3 | Restaurant verification | Approve a restaurant, it appears on customer home |
| 4 | Menu and ordering | Owner adds item → customer orders → owner accepts |
| 5 | Hygiene photo system | Three fails auto-suspend the restaurant |
| 6 | Reviews and fake detection | Cancelled order blocked; generic review flagged |

See `PROJECT_STRUCTURE.md` for the full plan, table list, and scoring weights.

---

## Team

Md. Ashikur Rahman Siyam · Shudarshan Ghosh Durjoy
