# NoCap — How To Run & Test

## Quick start (no backend needed)

Open `frontend/index.html` in a browser. That's it.

`js/api.js` has `USE_MOCK = true`, so every screen runs off `js/mock-data.js`,
which mirrors `database/seed.sql`. When Parts 2–6 are built, change that one
line to `false` and the same pages call the real API instead.

**VS Code tip:** install the Live Server extension, right-click `index.html`,
"Open with Live Server". Plain file:// works too.

---

## Layout

There is no page-inside-a-card wrapper any more. Every screen is a normal
full-width web page:

```
topbar   logo + NoCap + nav links + role badge
page     centred content, max 1180px
tabbar   phone only, fixed to the bottom
```

The same 20 HTML files serve both layouts — one stylesheet, no duplicated
markup. The switch happens at **900px**:

| Width | Navigation | Cards |
|---|---|---|
| Under 900px | Bottom tab bar | One column |
| 900px and up | Links in the top bar | Two columns |
| 1340px and up | Links in the top bar | Three columns |

The nav links are written twice in each file — once as `.topnav`, once as
`.tabbar` — and CSS hides whichever doesn't apply. Cheap duplication in
generated markup, and each one gets styled properly for its context instead
of fighting one set of rules.

To check both: drag the browser window narrower and watch the top links drop
into the bottom bar, or press F12 and use the device toolbar.

---

## Colour system

All colours are CSS variables at the top of `css/style.css`. Change them
there and every screen follows.

| Variable | Hex | Meaning |
|---|---|---|
| `--bg` | `#0A0E14` | Page background, deep slate |
| `--surface` | `#141A23` | Cards |
| `--line` | `#263242` | Borders |
| `--primary` | `#FF6B3D` | Anything the user should act on |
| `--success` | `#22C55E` | Verified, approved, passed |
| `--info` | `#38BDF8` | Pending, in progress |
| `--danger` | `#F43F5E` | Failed, flagged, removed |
| `--muted` | `#8A99AB` | Secondary text |

The reasoning: a food app wants warmth, a trust product wants calm. Warm
coral carries the appetite and every call to action; the cool slate base
keeps the verification and moderation screens looking serious rather than
loud. Status colours never do double duty — green only ever means verified
or passed, rose only ever means failed or flagged, so a user learns the
code once and it holds across all three roles.

The JS emits class names `gold`, `blue`, `green`, `red`. Those are historical
names mapped to `--primary`, `--info`, `--success`, `--danger` in the
stylesheet, so recolouring never means touching JavaScript.

---

## Logo

- `assets/logo.svg` — full delivery bike with the food box. Login screen,
  report cover, slides.
- `assets/logo-mark.svg` — square badge version with thicker strokes so it
  stays readable down to about 24px. Top bar and browser favicon.

Both are plain SVG in the palette above, so they scale cleanly and you can
recolour them by editing the gradient stops at the top of each file.

---

## Demo accounts — password `nocap123` for all

| Role | Email | What to look at |
|---|---|---|
| Customer | ashikur@gmail.com | Ordering, reviews |
| Restaurant (approved) | kamrul@palazzio.com | Live dashboard, orders, menu |
| Restaurant (2 hygiene fails) | farhana@bbites.com | Suspension warning |
| Restaurant (pending approval) | tanvir@bking.com | Waiting on admin |
| Admin | admin@nocap.com.bd | Approvals, moderation (2FA: any 6 digits) |

On the login screen, tap any row in the DEMO ACCOUNTS card to auto-fill it.
Pick the right role chip first (Customer / Restaurant / Admin).

---

## Demo script for your presentation

Run these five in order. Each one shows a different piece of the two core features.

### 1. Ordering (customer)
Login as **ashikur@gmail.com** → home shows only 2 restaurants, each with a
hygiene badge → tap Pizza Palazzio → add items → View Cart → Place Order →
tracking screen with the 5-step timeline.

### 2. Restaurant receives it (owner)
Log out → login as **kamrul@palazzio.com** (Restaurant role) → Orders tab →
the order you just placed sits under "New" → Accept Order → Start Preparing.
Go back to the customer's tracking screen and the status has moved.

### 3. The review rule (customer)
Login as **ashikur@gmail.com** → My Orders. Notice:
- A delivered order shows **Write Review**
- The cancelled order says **"No review allowed — order was not completed"**
- Already-reviewed orders show the rating, not another button

That's feature 2's core rule, visible on screen.

### 4. Verification (admin)
Login as **admin@nocap.com.bd** → dashboard shows 1 pending verification →
Verify tab → Biryani King → the 4-stage detail with inspection scores
(24+23+21+26 = 94) and the officer's note → **Approve & Publish**.

Now log back in as the customer: **Biryani King appears on home** with
hygiene score 94. Before approval it was invisible. That's feature 1.

### 5. Fake review detection (admin)
Admin → Reviews tab. The flagged review "Best pizza ever!" shows 75% confidence
with each signal broken out — short comment, duplicate text, new account,
generic phrase. Choose **Keep** or **Remove**. Nothing is auto-deleted.

Also worth showing: Hygiene tab → Biryani Bites is 1 fail from automatic
suspension, with a Suspend Now button.

---

## Resetting the demo

Everything you do is saved in the browser's localStorage. To start clean,
open the browser console (F12) and run:

```js
Object.keys(localStorage).filter(k => k.startsWith("nocap_")).forEach(k => localStorage.removeItem(k));
```

Then refresh. All demo data returns to its starting state.

---

## Part 1 — database setup (for the backend later)

```bash
mysql -u root -p < database/schema.sql
mysql -u root -p < database/seed.sql
```

Check it worked:

```sql
USE nocap;
SHOW TABLES;                                    -- 11 tables
SELECT role, COUNT(*) FROM users GROUP BY role; -- 1 admin, 3 owners, 3 customers
SELECT name, status, hygiene_score FROM restaurants;
```

Then set your MySQL password in
`backend/src/main/resources/application.properties` and run:

```bash
cd backend
mvn spring-boot:run
```

The app should start and print the API address. `ddl-auto=validate` means
Hibernate checks your entity classes against the tables you just created —
if it starts cleanly, your 11 entities and 11 tables match. That is the
Part 1 test passing.

**Lombok note:** the entities use `@Data` to generate getters and setters.
IntelliJ needs the Lombok plugin (bundled in recent versions); VS Code needs
"Lombok Annotations Support". If you'd rather avoid it, delete the Lombok
dependency from `pom.xml` and let your IDE generate the getters instead.

---

## What is real vs. what is still a stub

**Working now, in the browser:**
- All three logins with role-based redirect
- Search and filter restaurants; only approved ones show
- Menu browsing, cart with quantity control, checkout, order placement
- Order status moving through the 5 stages, driven by the owner's actions
- Review submission with the delivered-order rule enforced
- Owner: menu availability toggle, add item, order acceptance, hygiene upload
- Admin: approve, reject, suspend, review moderation
- Every change is visible across roles

**Still stubs (built in Parts 2–6):**
- Password hashing and real sessions — mock mode compares plain text
- File upload for documents and kitchen photos — the button simulates a score
- The fake-review scoring runs on the server in Part 6; the frontend only
  displays the result
- 2FA on the admin login accepts any 6 digits

---

## When you build the backend

The frontend is already shaped for it. Every data function has both branches:

```js
async function getRestaurants() {
  if (USE_MOCK) return withOverrides(copy(MOCK.restaurants)).filter(r => r.status === "APPROVED");
  return apiGet("/customer/restaurants");   // <- this is what Part 4 must return
}
```

So the API endpoints are already specified by the code. Build the controller
to return the same shape as the matching mock array, flip `USE_MOCK` to
`false`, and the screen works unchanged.
