# NoCap

Verified & hygiene-assured food delivery.
*No fake reviews. No dirty kitchens.*

**Stack:** HTML / CSS / JavaScript (Leaflet + OpenStreetMap for live maps) · Java (Spring Boot) · MySQL

---

## Core Features

**1. Restaurant Verification** — a restaurant is invisible to customers until it
passes four stages: documents, owner identity, kitchen inspection, admin approval.
After approval it joins a random kitchen-photo cycle; three consecutive failed
checks suspend it automatically.

**2. Fake Review Detection** — a review must be linked to a delivered order
(enforced by the database itself). Reviews that pass that check are scored on
four signals; above 70 they are flagged for an admin, never auto-deleted.

**3. Live Delivery Tracking** — real browser-geolocation-based nearby restaurant
search on Home, and a live map on the tracking screen showing the restaurant and
the assigned rider's current position (updated every few seconds while the rider
is online). Delivery fee is calculated from actual straight-line distance once
both restaurant and customer coordinates are known.

**4. NoCap Assistant** — a lightweight rule-based chatbot (bottom-right bubble on
every customer screen) that answers common questions about order tracking,
delivery fees, hygiene scores, payments, and how to use the app. No API key or
external service required — pure keyword-intent matching in `js/chatbot.js`.

All data is real — there is no mock/demo mode. Every account (Customer,
Restaurant Owner, Admin, Rider) is created through actual signup and persisted
to MySQL.

---

## Four User Types

| Role | Entry point | Screens |
|---|---|---|
| Customer | `frontend/index.html` | 8 |
| Restaurant Owner | `frontend/restaurant/dashboard.html` | 6 |
| Admin | `frontend/admin/login.html` | 6 |
| Rider | `frontend/rider/login.html` | 6 |

One `users` table with a `role` column drives all four — see `js/auth.js`.
Riders have an additional `riders` row (NID, live GPS position, earnings) and
`deliveries` row per active job — see `js/rider.js`.

---

## Setup

1. `mysql -u root -p < database/schema.sql`
2. `mysql -u root -p < database/seed.sql` *(optional — not required; every role can self-register through the real signup screens)*
3. Set your MySQL password in `backend/src/main/resources/application.properties`
4. `cd backend && mvn spring-boot:run` — API on `http://localhost:8080` (Hibernate auto-migrates new columns via `ddl-auto=update`, so it's safe to run against an older database too)
5. Open `frontend/index.html` (VS Code Live Server works well)

Browser location permission (allowed) is needed for: nearby-restaurant search on
Home, distance-based delivery fee + live map at checkout/tracking, and the
rider dashboard's live GPS updates while online.

---

## Build Order

Every file in this project has a `Build in: Part N` comment at the top.
Work through the parts in order — each one is testable on its own.

| Part | What | Test when done |
|---|---|---|
| 1 | Database, models, repositories, project setup | App starts, all tables visible |
| 2 | Auth for all four roles | Four logins reach four dashboards |
| 3 | Restaurant verification | Approve a restaurant, it appears on customer home + map |
| 4 | Menu and ordering | Owner adds item → customer orders → owner accepts → rider delivers |
| 5 | Hygiene photo system | Three fails auto-suspend the restaurant |
| 6 | Reviews and fake detection | Cancelled order blocked; generic review flagged |
| 7 | Live map + rider GPS | Tracking screen shows rider marker moving while online |

See `PROJECT_STRUCTURE.md` for the full plan, table list, and scoring weights.

---

## Team

Md. Ashikur Rahman Siyam · Shudarshan Ghosh Durjoy
