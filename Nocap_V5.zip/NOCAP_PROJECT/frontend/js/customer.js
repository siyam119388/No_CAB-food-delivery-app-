// ============================================
// NoCap Customer Module
// Restaurant list, ordering, tracking
// ============================================

const API_BASE = "http://localhost:8080/api";

// ============================================
// HOME SCREEN - Load nearby restaurants
// ============================================

function loadHome() {
  // Get user's geolocation
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      function(position) {
        const userLat = position.coords.latitude;
        const userLon = position.coords.longitude;
        console.log(`📍 User Location: ${userLat}, ${userLon}`);
        
        // Fetch nearby restaurants
        fetchNearbyRestaurants(userLat, userLon);
      },
      function(error) {
        console.warn("❌ Geolocation denied, using default Dhaka coordinates");
        // Fallback to Dhaka center coordinates
        fetchNearbyRestaurants(23.8103, 90.4125);
      }
    );
  } else {
    console.warn("❌ Geolocation not supported, using default");
    fetchNearbyRestaurants(23.8103, 90.4125);
  }
}

// Fetch nearby restaurants from API
function fetchNearbyRestaurants(lat, lon) {
  const radiusKm = 10; // Search within 10km

  fetch(`${API_BASE}/restaurants/nearby?latitude=${lat}&longitude=${lon}&radiusKm=${radiusKm}`)
    .then(res => res.json())
    .then(restaurants => {
      console.log("✅ Restaurants fetched:", restaurants);
      displayRestaurants(restaurants);
      renderNearbyMap(restaurants, lat, lon);
      window.allRestaurants = restaurants; // Store globally for filtering
    })
    .catch(err => {
      console.error("❌ Error fetching restaurants:", err);
      // Fallback to all restaurants
      getAllRestaurants();
    });
}

let nearbyMapInstance = null;

// Live Leaflet map: user's own position + nearby restaurants
function renderNearbyMap(restaurants, userLat, userLon) {
  const mapEl = document.getElementById("nearbyMap");
  if (!mapEl || typeof L === "undefined") return;

  if (!nearbyMapInstance) {
    nearbyMapInstance = L.map("nearbyMap").setView([userLat, userLon], 13);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "&copy; OpenStreetMap contributors",
      maxZoom: 19
    }).addTo(nearbyMapInstance);
  } else {
    nearbyMapInstance.setView([userLat, userLon], 13);
    nearbyMapInstance.eachLayer(layer => {
      if (layer instanceof L.Marker) nearbyMapInstance.removeLayer(layer);
    });
  }

  L.marker([userLat, userLon])
    .addTo(nearbyMapInstance)
    .bindPopup("You are here")
    .openPopup();

  (restaurants || []).forEach(r => {
    if (!r.latitude || !r.longitude) return;
    const marker = L.marker([parseFloat(r.latitude), parseFloat(r.longitude)]).addTo(nearbyMapInstance);
    marker.bindPopup(`<b>${r.name}</b><br>${r.cuisine || ""}<br>${calculateDistance(r.latitude, r.longitude)}km away`);
    marker.on("click", () => viewRestaurantDetails(r.id));
  });

  setTimeout(() => nearbyMapInstance.invalidateSize(), 200);
}

// Get all restaurants (fallback)
function getAllRestaurants() {
  fetch(`${API_BASE}/restaurants`)
    .then(res => res.json())
    .then(restaurants => {
      console.log("✅ All restaurants fetched:", restaurants);
      displayRestaurants(restaurants.filter(r => r.status === "APPROVED"));
      window.allRestaurants = restaurants;
    })
    .catch(err => console.error("❌ Error fetching restaurants:", err));
}

// Display restaurant cards
function displayRestaurants(restaurants) {
  const container = document.getElementById("restaurantList");
  container.innerHTML = ""; // Clear previous
  
  if (!restaurants || restaurants.length === 0) {
    container.innerHTML = `<p style="text-align:center; color:#999;">No restaurants found nearby</p>`;
    return;
  }
  
  restaurants.forEach(r => {
    const distance = r.latitude && r.longitude ? 
      `📍 ${calculateDistance(r.latitude, r.longitude)}km away` : 
      "📍 Unknown distance";
    
    const card = document.createElement("div");
    card.className = "restaurant-card";
    card.innerHTML = `
      <div class="restaurant-header">
        <div class="restaurant-icon">${getEmoji(r.cuisine)}</div>
        <div class="restaurant-info">
          <h3>${r.name}</h3>
          <p class="cuisine">${r.cuisine}</p>
          <p class="distance">${distance}</p>
        </div>
        <div class="restaurant-rating">
          <span class="rating">⭐ ${r.rating || 0}</span>
          <span class="hygiene">🏥 ${r.hygieneScore || 0}</span>
        </div>
      </div>
      <div class="restaurant-details">
        <span class="prep-time">⏱️ ~${r.prepTime || 30}min</span>
        <span class="delivery-fee">🚚 ৳${r.deliveryFee || 0}</span>
      </div>
    `;
    
    card.onclick = () => viewRestaurantDetails(r.id);
    container.appendChild(card);
  });
}

// Calculate distance between two coordinates (simple Haversine)
function calculateDistance(restLat, restLon) {
  // Default to Dhaka if no user location
  const userLat = 23.8103;
  const userLon = 90.4125;
  
  const R = 6371; // Earth radius in km
  const dLat = (parseFloat(restLat) - userLat) * Math.PI / 180;
  const dLon = (parseFloat(restLon) - userLon) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(userLat * Math.PI / 180) * Math.cos(parseFloat(restLat) * Math.PI / 180) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c;
  
  return distance.toFixed(1);
}

// Get emoji for cuisine
function getEmoji(cuisine) {
  const emojis = {
    "Bengali": "🍲",
    "Biryani": "🍚",
    "Italian": "🍝",
    "Fast Food": "🍔",
    "Chinese": "🥡",
    "Seafood": "🦞",
    "Desi": "🍛",
    "Pizza": "🍕"
  };
  return emojis[cuisine] || "🍽️";
}

// View restaurant details
function viewRestaurantDetails(restaurantId) {
  localStorage.setItem("selectedRestaurantId", restaurantId);
  window.location.href = "restaurant.html";
}

// ============================================
// SEARCH & FILTER
// ============================================

document.addEventListener("DOMContentLoaded", function() {
  // Search functionality
  const searchInput = document.getElementById("search");
  if (searchInput) {
    searchInput.addEventListener("input", function(e) {
      const query = e.target.value.toLowerCase();
      const filtered = window.allRestaurants.filter(r => 
        r.name.toLowerCase().includes(query) ||
        r.cuisine.toLowerCase().includes(query)
      );
      displayRestaurants(filtered);
    });
  }
  
  // Cuisine filter
  const chips = document.querySelectorAll(".chip");
  chips.forEach(chip => {
    chip.addEventListener("click", function() {
      // Remove 'on' from all chips
      chips.forEach(c => c.classList.remove("on"));
      // Add 'on' to clicked chip
      this.classList.add("on");
      
      const cuisine = this.getAttribute("data-cuisine");
      let filtered = window.allRestaurants;
      
      if (cuisine !== "All") {
        filtered = filtered.filter(r => r.cuisine === cuisine);
      }
      
      displayRestaurants(filtered);
    });
  });
});

// ============================================
// RESTAURANT DETAILS
// ============================================

function getRestaurantDetails(restaurantId) {
  return fetch(`${API_BASE}/restaurants/${restaurantId}`)
    .then(res => res.json())
    .catch(err => {
      console.error("Error fetching restaurant:", err);
      return null;
    });
}

function getMenuItems(restaurantId) {
  return fetch(`${API_BASE}/menu?restaurantId=${restaurantId}`)
    .then(res => res.json())
    .catch(err => {
      console.error("Error fetching menu:", err);
      return [];
    });
}

// ============================================
// CART MANAGEMENT
// ============================================

function addToCart(menuItemId, name, price, quantity = 1) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  
  const existing = cart.find(item => item.menuItemId === menuItemId);
  if (existing) {
    existing.quantity += quantity;
  } else {
    cart.push({ menuItemId, name, price, quantity });
  }
  
  localStorage.setItem("cart", JSON.stringify(cart));
  console.log("✅ Added to cart:", name);
  alert(`✅ ${name} added to cart!`);
}

function getCart() {
  return JSON.parse(localStorage.getItem("cart")) || [];
}

function removeFromCart(menuItemId) {
  let cart = getCart();
  cart = cart.filter(item => item.menuItemId !== menuItemId);
  localStorage.setItem("cart", JSON.stringify(cart));
  console.log("✅ Removed from cart");
}

function clearCart() {
  localStorage.removeItem("cart");
  console.log("✅ Cart cleared");
}

// ============================================
// ORDER PLACEMENT
// ============================================

function placeOrder(restaurantId, totalPrice, paymentMethod = "COD") {
  const user = getCurrentUser();
  if (!user) {
    alert("❌ Please login first");
    window.location.href = "index.html";
    return;
  }
  
  const cart = getCart();
  if (cart.length === 0) {
    alert("❌ Cart is empty");
    return;
  }
  
  const orderData = {
    customerId: user.id,
    restaurantId: restaurantId,
    orderItems: cart.map(item => ({
      menuItemId: item.menuItemId,
      name: item.name,
      price: item.price,
      quantity: item.quantity
    })),
    totalPrice: totalPrice,
    paymentMethod: paymentMethod
  };
  
  fetch(`${API_BASE}/orders`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(orderData)
  })
    .then(res => res.json())
    .then(order => {
      console.log("✅ Order placed:", order);
      localStorage.setItem("lastOrderId", order.id);
      clearCart();
      alert("✅ Order placed successfully!");
      window.location.href = "tracking.html";
    })
    .catch(err => {
      console.error("❌ Error placing order:", err);
      alert("❌ Failed to place order");
    });
}

// ============================================
// ORDER TRACKING
// ============================================

function getOrderDetails(orderId) {
  return fetch(`${API_BASE}/orders/${orderId}`)
    .then(res => res.json())
    .catch(err => {
      console.error("Error fetching order:", err);
      return null;
    });
}

function getCustomerOrders(customerId) {
  return fetch(`${API_BASE}/customers/${customerId}/orders`)
    .then(res => res.json())
    .catch(err => {
      console.error("Error fetching customer orders:", err);
      return [];
    });
}

// ============================================
// HELPER FUNCTIONS
// ============================================

function getCurrentUser() {
  return JSON.parse(localStorage.getItem("currentUser"));
}

function firstName(fullName) {
  return fullName ? fullName.split(" ")[0] : "Customer";
}

// Auto-load home on page load
if (document.location.pathname.includes("home.html")) {
  loadHome();
}
// ============================================
// RESTAURANT DETAILS SCREEN
// ============================================

function loadRestaurant() {
  const restaurantId = localStorage.getItem("selectedRestaurantId");
  
  if (!restaurantId) {
    alert("❌ No restaurant selected");
    window.location.href = "home.html";
    return;
  }
  
  // Fetch restaurant details
  getRestaurantDetails(restaurantId)
    .then(restaurant => {
      if (!restaurant) {
        alert("❌ Restaurant not found");
        return;
      }
      displayRestaurantDetails(restaurant);
      
      // Fetch and display menu
      getMenuItems(restaurantId)
        .then(menuItems => {
          displayMenuItems(menuItems);
        });
    });
  
  // Update cart bar on load
  updateCartBar();
}

function displayRestaurantDetails(restaurant) {
  document.getElementById("restName").textContent = restaurant.name;
  document.getElementById("restSub").textContent = `${restaurant.address} • ⭐ ${restaurant.rating || 0}`;
  
  // Hygiene score
  const score = restaurant.hygieneScore || 0;
  document.getElementById("score").textContent = score;
  document.getElementById("scoreBar").style.width = score + "%";
  
  // Rating line
  const ratingLine = `⭐ ${restaurant.rating || 0}/5 rating • ${restaurant.cuisine}`;
  document.getElementById("ratingLine").textContent = ratingLine;
  
  // Store for later use
  window.selectedRestaurant = restaurant;
}

function displayMenuItems(menuItems) {
  if (!menuItems || menuItems.length === 0) {
    document.getElementById("menuList").innerHTML = "<p style='text-align:center; color:#999;'>No menu items available</p>";
    return;
  }
  
  // Group by category
  const categories = {};
  menuItems.forEach(item => {
    const cat = item.category || "Other";
    if (!categories[cat]) categories[cat] = [];
    categories[cat].push(item);
  });
  
  // Create category tabs
  const catTabs = document.getElementById("catTabs");
  catTabs.innerHTML = "";
  let isFirst = true;
  
  Object.keys(categories).forEach(category => {
    const tab = document.createElement("span");
    tab.className = `chip ${isFirst ? "on" : ""}`;
    tab.textContent = category;
    tab.onclick = () => {
      document.querySelectorAll(".chip").forEach(t => t.classList.remove("on"));
      tab.classList.add("on");
      renderMenuCategory(categories[category]);
    };
    catTabs.appendChild(tab);
    isFirst = false;
  });
  
  // Display first category by default
  const firstCategory = Object.keys(categories)[0];
  renderMenuCategory(categories[firstCategory]);
}

function renderMenuCategory(items) {
  const container = document.getElementById("menuList");
  container.innerHTML = "";
  
  items.forEach(item => {
    const card = document.createElement("div");
    card.className = "menu-item-card";
    card.innerHTML = `
      <div class="menu-item-header">
        <div class="menu-item-info">
          <h3>${item.name}</h3>
          <p class="menu-item-desc">${item.description || "Delicious item"}</p>
          <p class="menu-item-price">৳${item.price}</p>
        </div>
        <div class="menu-item-icon">${item.imageUrl ? `<img src="${item.imageUrl}" style="width:48px;height:48px;object-fit:cover;border-radius:10px">` : getEmoji(item.category)}</div>
      </div>
      <div class="menu-item-actions">
        <div class="qty-selector">
          <button class="qty-btn" onclick="decreaseQty(${item.id})">−</button>
          <span class="qty-display" id="qty-${item.id}">0</span>
          <button class="qty-btn" onclick="increaseQty(${item.id}, '${item.name}', ${item.price})">+</button>
        </div>
      </div>
    `;
    container.appendChild(card);
  });
}

let itemQuantities = {}; // Track quantities

function increaseQty(itemId, itemName, itemPrice) {
  if (!itemQuantities[itemId]) itemQuantities[itemId] = 0;
  itemQuantities[itemId]++;
  
  document.getElementById(`qty-${itemId}`).textContent = itemQuantities[itemId];
  
  // Add to cart
  addToCart(itemId, itemName, itemPrice, 1);
  updateCartBar();
}

function decreaseQty(itemId) {
  if (itemQuantities[itemId] && itemQuantities[itemId] > 0) {
    itemQuantities[itemId]--;
    document.getElementById(`qty-${itemId}`).textContent = itemQuantities[itemId];
    
    if (itemQuantities[itemId] === 0) {
      removeFromCart(itemId);
    }
    updateCartBar();
  }
}

function updateCartBar() {
  const cart = getCart();
  const cartCount = cart.length;
  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  const cartBar = document.getElementById("cartBar");
  
  if (cartCount === 0) {
    cartBar.classList.add("hide");
  } else {
    cartBar.classList.remove("hide");
    document.getElementById("cartCount").textContent = `${cartCount} items in cart`;
    document.getElementById("cartTotal").textContent = `৳${cartTotal.toFixed(2)}`;
  }
}

// ============================================
// CHECKOUT SCREEN
// ============================================

let selectedPaymentMethod = "COD";

function loadCheckout() {
  const cart = getCart();
  const container = document.getElementById("cartItems");
  const user = getCurrentUser();

  if (!cart || cart.length === 0) {
    container.innerHTML = "<p style='text-align:center; color:#999;'>Your cart is empty</p>";
    document.getElementById("payBtn").disabled = true;
  } else {
    container.innerHTML = "";
    cart.forEach(item => {
      const row = document.createElement("div");
      row.className = "li";
      row.innerHTML = `
        <span>${item.name} <span class="sub">x${item.quantity}</span></span>
        <span>${tk(item.price * item.quantity)}</span>
      `;
      container.appendChild(row);
    });
  }

  document.getElementById("addressText").textContent = (user && user.address) || "Add a delivery address";

  // Payment method selection
  document.querySelectorAll(".js-pay").forEach(card => {
    card.addEventListener("click", function () {
      document.querySelectorAll(".js-pay").forEach(c => {
        c.classList.remove("card-green");
        const tick = c.querySelector(".js-tick");
        if (tick) tick.textContent = "Select";
      });
      this.classList.add("card-green");
      const tick = this.querySelector(".js-tick");
      if (tick) tick.textContent = "\u2713";
      selectedPaymentMethod = this.getAttribute("data-method");
    });
  });

  updateBillSummary(cart);

  document.getElementById("payBtn").addEventListener("click", function () {
    const restaurantId = localStorage.getItem("selectedRestaurantId");

    if (!restaurantId) {
      alert("\u274c No restaurant selected");
      window.location.href = "home.html";
      return;
    }

    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    submitOrder(restaurantId, subtotal, selectedPaymentMethod, (user && user.address) || "");
  });
}

function updateBillSummary(cart) {
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = window.selectedRestaurant && window.selectedRestaurant.deliveryFee
    ? Number(window.selectedRestaurant.deliveryFee)
    : 50;

  document.getElementById("subTotal").textContent = tk(subtotal);
  document.getElementById("delFee").textContent = tk(deliveryFee);
  document.getElementById("grandTotal").textContent = tk(subtotal + deliveryFee);
}

function submitOrder(restaurantId, totalPrice, paymentMethod, address) {
  const user = getCurrentUser();
  if (!user) {
    alert("\u274c Please login first");
    window.location.href = "index.html";
    return;
  }

  const cart = getCart();
  if (cart.length === 0) {
    alert("\u274c Cart is empty");
    return;
  }

  const finishOrder = (location) => {
    const orderData = {
      customerId: user.id,
      restaurantId: restaurantId,
      address: address,
      paymentMethod: paymentMethod,
      deliveryLat: location ? location.coords.latitude : null,
      deliveryLng: location ? location.coords.longitude : null,
      orderItems: cart.map(item => ({
        menuItemId: item.menuItemId,
        quantity: item.quantity
      }))
    };

    fetch(`${API_BASE}/orders`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(orderData)
    })
      .then(res => {
        if (!res.ok) throw new Error("Order failed");
        return res.json();
      })
      .then(order => {
        localStorage.setItem("lastOrderId", order.id);
        clearCart();
        window.location.href = "tracking.html";
      })
      .catch(err => {
        console.error("\u274c Error placing order:", err);
        alert("\u274c Failed to place order");
      });
  };

  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (position) => finishOrder(position),
      () => finishOrder(null),
      { timeout: 8000 }
    );
  } else {
    finishOrder(null);
  }
}


// ============================================
// TRACKING SCREEN
// ============================================

const ORDER_STEPS = ["PLACED", "ACCEPTED", "PREPARING", "OUT_FOR_DELIVERY", "DELIVERED"];
const STEP_LABELS = {
  PLACED: "Order placed",
  ACCEPTED: "Restaurant accepted",
  PREPARING: "Preparing your food",
  OUT_FOR_DELIVERY: "Out for delivery",
  DELIVERED: "Delivered"
};

function loadTracking() {
  const orderId = localStorage.getItem("lastOrderId");

  if (!orderId) {
    alert("\u274c No recent order found");
    window.location.href = "orders.html";
    return;
  }

  const poll = () => {
    getOrderDetails(orderId).then(order => {
      if (!order) {
        alert("\u274c Order not found");
        return;
      }
      renderTracking(order);

      // Keep polling every 8s while the order is still moving, so the
      // live map updates as the rider's position changes.
      if (!["DELIVERED", "CANCELLED"].includes(order.status)) {
        setTimeout(poll, 8000);
      }
    });
  };

  poll();
}

let trackMapInstance = null;

function renderTracking(order) {
  const currentIndex = ORDER_STEPS.indexOf(order.status);
  const progressPct = currentIndex >= 0 ? ((currentIndex + 1) / ORDER_STEPS.length) * 100 : 0;

  document.getElementById("etaBar").style.width = progressPct + "%";
  document.getElementById("eta").textContent =
    order.status === "DELIVERED" ? "Delivered" :
    order.status === "CANCELLED" ? "Cancelled" : "30-40 min";

  const stepsContainer = document.getElementById("steps");
  stepsContainer.innerHTML = "";

  ORDER_STEPS.forEach((step, i) => {
    const row = document.createElement("div");
    row.className = "li";
    const done = currentIndex >= i;
    row.innerHTML = `
      <span>${done ? "\u2705" : "\u25cb"} ${STEP_LABELS[step]}</span>
    `;
    stepsContainer.appendChild(row);
  });

  document.getElementById("orderNo").textContent = "#" + order.id;
  document.getElementById("itemCount").textContent = (order.items ? order.items.length : 0) + " items";
  document.getElementById("payMethod").textContent = order.paymentMethod;

  renderTrackingMap(order);
}

// Live Leaflet map: restaurant + rider's current position (once a rider has been assigned)
function renderTrackingMap(order) {
  const wrap = document.getElementById("trackMapWrap");
  const mapEl = document.getElementById("trackMap");
  if (!wrap || !mapEl || typeof L === "undefined") return;

  if (!order.restaurantLat || !order.restaurantLng) {
    wrap.classList.add("hide");
    return;
  }

  wrap.classList.remove("hide");

  const restLat = parseFloat(order.restaurantLat);
  const restLng = parseFloat(order.restaurantLng);

  if (!trackMapInstance) {
    trackMapInstance = L.map("trackMap").setView([restLat, restLng], 14);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "&copy; OpenStreetMap contributors",
      maxZoom: 19
    }).addTo(trackMapInstance);
  }

  trackMapInstance.eachLayer(layer => {
    if (layer instanceof L.Marker) trackMapInstance.removeLayer(layer);
  });

  L.marker([restLat, restLng]).addTo(trackMapInstance).bindPopup(order.restaurantName || "Restaurant");

  if (order.riderLat && order.riderLng) {
    const riderLat = parseFloat(order.riderLat);
    const riderLng = parseFloat(order.riderLng);
    L.marker([riderLat, riderLng]).addTo(trackMapInstance).bindPopup(order.riderName ? `Rider: ${order.riderName}` : "Your rider");
    trackMapInstance.fitBounds([[restLat, restLng], [riderLat, riderLng]], { padding: [30, 30] });
  }

  setTimeout(() => trackMapInstance.invalidateSize(), 200);
}


// ============================================
// MY ORDERS SCREEN + REVIEW
// ============================================

function loadOrders() {
  const user = getCurrentUser();
  if (!user) return;

  getCustomerOrders(user.id).then(orders => {
    const container = document.getElementById("orderList");
    container.innerHTML = "";

    if (!orders || orders.length === 0) {
      container.innerHTML = "<p style='text-align:center; color:#999;'>No orders yet</p>";
      return;
    }

    orders.forEach(order => {
      const card = document.createElement("div");
      card.className = "card";
      card.innerHTML = `
        <div class="row">
          <div>
            <div class="name">Order #${order.id}</div>
            <div class="sub">${order.status}</div>
          </div>
          <div class="gold">${tk(order.total || 0)}</div>
        </div>
      `;

      if (order.status === "DELIVERED") {
        const reviewBtn = document.createElement("button");
        reviewBtn.className = "btn-out btn-sm";
        reviewBtn.style = "margin-top:8px";
        reviewBtn.textContent = "Write a review";
        reviewBtn.onclick = () => openReviewForm(order.id);
        card.appendChild(reviewBtn);
      }

      container.appendChild(card);
    });
  });
}

let selectedRating = 5;

function initReviewForm() {
  document.querySelectorAll(".star").forEach((star, index) => {
    star.addEventListener("click", () => {
      selectedRating = index + 1;
      document.querySelectorAll(".star").forEach((s, i) => {
        s.style.opacity = i <= index ? "1" : "0.35";
      });
    });
  });

  document.getElementById("cancelReview").addEventListener("click", () => {
    document.getElementById("reviewBox").classList.add("hide");
  });

  document.getElementById("submitReview").addEventListener("click", () => {
    const orderId = document.getElementById("reviewOrderId").value;
    const comment = document.getElementById("reviewText").value.trim();
    const errBox = document.getElementById("reviewErr");

    errBox.textContent = "";

    if (!comment) {
      errBox.textContent = "Please write a short review.";
      return;
    }

    fetch(`${API_BASE}/reviews`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ orderId, rating: selectedRating, comment })
    })
      .then(async res => {
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Could not submit review");
        alert("\u2705 Review submitted!");
        document.getElementById("reviewBox").classList.add("hide");
        loadOrders();
      })
      .catch(err => {
        errBox.textContent = err.message;
      });
  });
}

function openReviewForm(orderId) {
  document.getElementById("reviewOrderId").value = orderId;
  document.getElementById("reviewText").value = "";
  document.getElementById("reviewErr").textContent = "";
  document.getElementById("reviewBox").classList.remove("hide");
  document.getElementById("reviewBox").scrollIntoView({ behavior: "smooth" });
}


// ============================================
// PROFILE SCREEN
// ============================================

function loadProfile() {
  const user = getCurrentUser();
  if (!user) return;

  const nameEl = document.querySelector(".js-username");
  const emailEl = document.querySelector(".js-useremail");
  const phoneEl = document.querySelector(".js-userphone");
  const addressEl = document.querySelector(".js-useraddress");

  if (nameEl) nameEl.textContent = user.name || "";
  if (emailEl) emailEl.textContent = user.email || "";
  if (phoneEl) phoneEl.textContent = user.phone || "-";
  if (addressEl) addressEl.textContent = user.address || "-";

  getCustomerOrders(user.id).then(orders => {
    document.getElementById("orderCount").textContent = orders ? orders.length : 0;
  });
}
