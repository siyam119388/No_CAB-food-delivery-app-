/* ============================================================
   chatbot.js — NoCap Assistant
   A small, self-contained rule-based support chatbot. Injects its
   own floating button + panel, so a page only needs to add:
     <script src="js/chatbot.js"></script>  (or ../js/... in subfolders)
   No backend or API key needed — this is intent-matching over
   keywords (Bangla + English), not a hosted LLM.
   ============================================================ */

(function () {

  const RESPONSES = [
    {
      intents: ["hi", "hello", "hey", "assalamualaikum", "salam", "হাই", "হ্যালো"],
      words: ["hi", "hello", "hey", "salam", "assalamualaikum"],
      reply: "Hi! I'm the NoCap Assistant \ud83d\udc4b I can help with order status, delivery fees, hygiene scores, and how to use the app. What do you need?"
    },
    {
      intents: ["order status", "track", "tracking", "where is my order", "amar order kothay", "order kothay"],
      words: ["track", "tracking", "status", "where"],
      reply: "You can track your order live on the Tracking page — it updates every few seconds and shows your rider once one is assigned. Open 'Orders' \u2192 pick the order \u2192 you'll be taken to live tracking.",
      link: { label: "Go to My Orders", href: "orders.html" }
    },
    {
      intents: ["delivery fee", "delivery charge", "koto tk", "koto taka", "shipping cost"],
      words: ["fee", "charge", "cost", "koto", "taka", "tk"],
      reply: "Delivery fee is based on straight-line distance between the restaurant and your delivery address (\u09f3 per km), calculated automatically at checkout once location access is allowed. If location isn't available, the restaurant's flat delivery fee is used instead."
    },
    {
      intents: ["hygiene", "hygiene score", "clean", "safe", "porishkar"],
      words: ["hygiene", "clean", "safe", "porishkar", "score"],
      reply: "Every restaurant on NoCap gets random kitchen-photo hygiene checks a few times a day. A restaurant that fails 3 checks in a row is automatically suspended until it appeals and passes again. The score you see on each restaurant card reflects their latest check."
    },
    {
      intents: ["how to order", "place order", "order korbo kivabe", "kivabe order", "how can i order", "how do i order"],
      words: ["order", "how", "place", "korbo", "kivabe", "kmne", "kivave"],
      reply: "Browse restaurants on Home \u2192 tap one \u2192 add items to your cart \u2192 go to Checkout \u2192 confirm your address and payment method (COD or bKash) \u2192 Place Order. You'll land on live tracking right after."
    },
    {
      intents: ["cancel order", "cancel", "bad off korbo"],
      words: ["cancel", "bad"],
      reply: "Right now cancellation isn't self-serve from the app once an order is placed. If it's genuinely urgent, contact the restaurant directly using the number on their profile."
    },
    {
      intents: ["review", "rating dibo", "review dibo"],
      words: ["review", "rating", "rate"],
      reply: "You can leave a review only after an order is marked Delivered — open 'Orders', find the delivered order, and tap 'Write a review'. This keeps reviews tied to real deliveries."
    },
    {
      intents: ["payment", "bkash", "cod", "cash on delivery"],
      words: ["payment", "pay", "bkash", "cod", "cash"],
      reply: "NoCap supports Cash on Delivery (COD) and bKash at checkout. Pick whichever you prefer on the Checkout page before placing the order."
    },
    {
      intents: ["restaurant", "verify", "verified", "approved"],
      words: ["verify", "verified", "approved", "restaurant"],
      reply: "Only restaurants approved by an admin (after document + hygiene checks) show up for customers. A restaurant still pending review won't appear on your Home feed."
    },
    {
      intents: ["rider", "delivery boy", "rider kothay"],
      words: ["rider", "kothay"],
      reply: "Once a restaurant marks your order 'Out for delivery', a rider gets assigned automatically and you can see their live position on the Tracking page's map."
    },
    {
      intents: ["contact", "support", "help", "problem", "somossa"],
      words: ["contact", "support", "help", "problem", "somossa"],
      reply: "For anything I can't help with, the fastest option is contacting the restaurant directly for order-specific issues, or an admin for account issues."
    },
    {
      intents: ["thanks", "thank you", "dhonnobad"],
      words: ["thanks", "thank", "dhonnobad"],
      reply: "You're welcome! Anything else I can help with?"
    }
  ];

  const FALLBACK =
    "I'm a simple assistant so I might not have that one \u2014 try asking about order tracking, delivery fees, hygiene scores, payments, or how to place an order.";

  function matchIntent(text) {
    const lower = text.toLowerCase();

    // 1) exact-phrase match (fast path, most specific)
    for (const entry of RESPONSES) {
      for (const keyword of entry.intents) {
        if (lower.includes(keyword)) return entry;
      }
    }

    // 2) word-overlap scoring — catches rephrasings like "how can i order"
    // that don't contain any exact phrase above.
    const tokens = lower.split(/[^a-z\u0980-\u09ff]+/).filter(Boolean);
    let best = null;
    let bestScore = 0;

    for (const entry of RESPONSES) {
      if (!entry.words) continue;
      let score = 0;
      for (const w of entry.words) {
        if (tokens.includes(w)) score++;
      }
      if (score > bestScore) {
        bestScore = score;
        best = entry;
      }
    }

    return bestScore > 0 ? best : null;
  }

  function buildWidget() {

    const style = document.createElement("style");
    style.textContent = `
      #ncChatBtn {
        position: fixed; bottom: 84px; right: 18px; z-index: 999;
        width: 56px; height: 56px; border-radius: 50%;
        background: linear-gradient(135deg,#F5B301,#E09B00);
        color: #1a1a1a; border: none; box-shadow: 0 4px 14px rgba(0,0,0,.25);
        font-size: 24px; cursor: pointer;
      }
      #ncChatPanel {
        position: fixed; bottom: 150px; right: 18px; z-index: 999;
        width: min(320px, 88vw); max-height: 60vh;
        background: #fff; border-radius: 14px; box-shadow: 0 8px 30px rgba(0,0,0,.3);
        display: none; flex-direction: column; overflow: hidden;
        font-family: inherit;
      }
      #ncChatPanel.open { display: flex; }
      #ncChatHead {
        background: #1a1a1a; color: #fff; padding: 12px 14px;
        font-weight: 700; display: flex; justify-content: space-between; align-items: center;
      }
      #ncChatHead span.sub { font-weight: 400; font-size: 11px; opacity: .7; display:block; }
      #ncChatClose { background: none; border: none; color: #fff; font-size: 18px; cursor: pointer; }
      #ncChatMsgs { flex: 1; overflow-y: auto; padding: 10px; background: #faf9f7; }
      .nc-msg { max-width: 85%; margin-bottom: 8px; padding: 8px 11px; border-radius: 10px; font-size: 13px; line-height: 1.4; color: #1a1a1a; }
      .nc-msg.bot { background: #fff; border: 1px solid #eee; color: #1a1a1a; }
      .nc-msg.user { background: #F5B301; margin-left: auto; color: #1a1a1a; }
      .nc-msg a { color: #1a1a1a; font-weight: 700; }
      #ncChatInputRow { display: flex; border-top: 1px solid #eee; }
      #ncChatInput { flex: 1; border: none; padding: 10px 12px; font-size: 13px; outline: none; }
      #ncChatSend { border: none; background: #F5B301; padding: 0 16px; font-weight: 700; cursor: pointer; }
    `;
    document.head.appendChild(style);

    const btn = document.createElement("button");
    btn.id = "ncChatBtn";
    btn.textContent = "\ud83e\udd16";
    btn.title = "NoCap Assistant";

    const panel = document.createElement("div");
    panel.id = "ncChatPanel";
    panel.innerHTML = `
      <div id="ncChatHead">
        <div>NoCap Assistant<span class="sub">Order help, delivery fees, hygiene &amp; more</span></div>
        <button id="ncChatClose">&times;</button>
      </div>
      <div id="ncChatMsgs"></div>
      <div id="ncChatInputRow">
        <input id="ncChatInput" placeholder="Ask something..." />
        <button id="ncChatSend">Send</button>
      </div>
    `;

    document.body.appendChild(btn);
    document.body.appendChild(panel);

    const msgs = panel.querySelector("#ncChatMsgs");
    const input = panel.querySelector("#ncChatInput");

    function addMsg(text, who, link) {
      const el = document.createElement("div");
      el.className = "nc-msg " + who;
      el.textContent = text;
      if (link) {
        el.appendChild(document.createElement("br"));
        const a = document.createElement("a");
        a.href = link.href;
        a.textContent = link.label + " \u2192";
        el.appendChild(a);
      }
      msgs.appendChild(el);
      msgs.scrollTop = msgs.scrollHeight;
    }

    function respond(text) {
      const match = matchIntent(text);
      if (match) {
        addMsg(match.reply, "bot", match.link);
      } else {
        addMsg(FALLBACK, "bot");
      }
    }

    function send() {
      const text = input.value.trim();
      if (!text) return;
      addMsg(text, "user");
      input.value = "";
      setTimeout(() => respond(text), 300);
    }

    btn.addEventListener("click", () => {
      panel.classList.toggle("open");
      if (panel.classList.contains("open") && msgs.children.length === 0) {
        addMsg("Hi! I'm the NoCap Assistant \ud83d\udc4b Ask me about order tracking, delivery fees, hygiene scores, payments, or how to order.", "bot");
      }
    });
    panel.querySelector("#ncChatClose").addEventListener("click", () => panel.classList.remove("open"));
    panel.querySelector("#ncChatSend").addEventListener("click", send);
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") send(); });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", buildWidget);
  } else {
    buildWidget();
  }
})();
