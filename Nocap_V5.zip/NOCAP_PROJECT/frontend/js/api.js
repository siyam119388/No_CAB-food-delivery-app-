/* ============================================================
   api.js — small shared helpers used by every page.
   All real data comes live from the Spring Boot backend at
   http://localhost:8080/api (see each page's own JS file for
   the actual fetch calls).
   ============================================================ */

const BASE_URL = "http://localhost:8080/api";

/* ---------- tiny helpers used by every page ---------- */

const $  = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

/** Bangladeshi Taka formatting. */
const tk = (n) => "\u09F3" + Number(n).toLocaleString("en-US");

/** Read ?id=3 from the address bar. */
const qs = (key) => new URLSearchParams(location.search).get(key);

/** Save / read data that survives page navigation (cart, last order id, etc). */
const store = {
  get:  (k, fallback) => { try { return JSON.parse(localStorage.getItem("nocap_" + k)) ?? fallback; }
                           catch (e) { return fallback; } },
  set:  (k, v) => localStorage.setItem("nocap_" + k, JSON.stringify(v)),
  del:  (k)    => localStorage.removeItem("nocap_" + k)
};

/**
 * Uploads a single image file (from a <input type="file"> element) to
 * the backend and resolves to its full URL (http://localhost:8080/uploads/...),
 * or null if no file was selected / the upload failed.
 */
async function uploadImageFile(fileInput) {
  if (!fileInput || !fileInput.files || fileInput.files.length === 0) return null;

  const formData = new FormData();
  formData.append("file", fileInput.files[0]);

  try {
    const response = await fetch(`${BASE_URL}/uploads`, { method: "POST", body: formData });
    const data = await response.json();
    if (!response.ok) {
      alert("\u274c " + (data.error || "Upload failed"));
      return null;
    }
    return "http://localhost:8080" + data.url;
  } catch (err) {
    console.error("Upload error:", err);
    alert("\u274c Could not upload image \u2014 is the backend running?");
    return null;
  }
}
