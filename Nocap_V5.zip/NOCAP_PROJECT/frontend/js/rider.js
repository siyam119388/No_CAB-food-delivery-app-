// ============================================
// NoCap Frontend - Rider JavaScript
// ============================================

const API_BASE_URL = 'http://localhost:8080/api';

// ============================================
// RIDER PROFILE MANAGEMENT
// ============================================

// Get rider profile
async function getRiderProfile() {
    try {
        const user = getCurrentUser();
        if (!user) return null;
        
        const response = await fetch(`${API_BASE_URL}/riders/profile/${user.riderId}`);
        if (!response.ok) throw new Error('Failed to fetch profile');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

// Update rider profile
async function updateRiderProfile(riderId, data) {
    try {
        const response = await fetch(`${API_BASE_URL}/riders/${riderId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if (!response.ok) throw new Error('Failed to update profile');
        alert('Profile updated successfully!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error updating profile');
    }
}

// ============================================
// DELIVERY MANAGEMENT
// ============================================

// Get available deliveries
async function getAvailableDeliveries() {
    try {
        const response = await fetch(`${API_BASE_URL}/riders/available-deliveries`);
        if (!response.ok) throw new Error('Failed to fetch deliveries');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
}

// Accept delivery
async function acceptDelivery(deliveryId, riderId) {
    try {
        const response = await fetch(`${API_BASE_URL}/riders/accept-delivery/${deliveryId}/${riderId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' }
        });
        if (!response.ok) throw new Error('Failed to accept delivery');
        alert('Delivery accepted! Start moving to pickup location.');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error accepting delivery');
    }
}

// Reject delivery
async function rejectDelivery(deliveryId, riderId, reason) {
    try {
        const response = await fetch(`${API_BASE_URL}/riders/reject-delivery/${deliveryId}/${riderId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ reason: reason })
        });
        if (!response.ok) throw new Error('Failed to reject delivery');
        alert('Delivery rejected!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error rejecting delivery');
    }
}

// Get rider deliveries
async function getRiderDeliveries() {
    try {
        const user = getCurrentUser();
        if (!user) return [];
        
        const response = await fetch(`${API_BASE_URL}/riders/deliveries/${user.riderId}`);
        if (!response.ok) throw new Error('Failed to fetch deliveries');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
}

// Get delivery details
async function getDeliveryDetails(deliveryId) {
    try {
        const response = await fetch(`${API_BASE_URL}/riders/delivery/${deliveryId}`);
        if (!response.ok) throw new Error('Failed to fetch delivery');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

// ============================================
// DELIVERY STATUS UPDATES
// ============================================

// Mark as picked up
async function markPickedUp(deliveryId) {
    try {
        const response = await fetch(`${API_BASE_URL}/riders/mark-pickup/${deliveryId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' }
        });
        if (!response.ok) throw new Error('Failed to update status');
        alert('Order picked up! Moving to delivery location...');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error updating status');
    }
}

// Mark as delivered
async function markDelivered(deliveryId) {
    try {
        const response = await fetch(`${API_BASE_URL}/riders/mark-delivered/${deliveryId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' }
        });
        if (!response.ok) throw new Error('Failed to mark delivered');
        alert('Order delivered! Earnings updated.');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error marking delivery');
    }
}

// ============================================
// ONLINE/OFFLINE STATUS
// ============================================

// Toggle online status
async function toggleOnlineStatus(riderId, isOnline) {
    try {
        const response = await fetch(`${API_BASE_URL}/riders/toggle-online/${riderId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ isOnline: isOnline })
        });
        if (!response.ok) throw new Error('Failed to update status');
        alert(isOnline ? 'You are now online!' : 'You are now offline.');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error updating online status');
    }
}

// Get online status
async function getOnlineStatus(riderId) {
    try {
        const response = await fetch(`${API_BASE_URL}/riders/status/${riderId}`);
        if (!response.ok) throw new Error('Failed to fetch status');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

// ============================================
// LIVE LOCATION TRACKING
// ============================================

let locationWatchId = null;

// Send one GPS position to the backend so customers tracking a
// delivery can see the rider's current spot on the map.
async function sendLocationUpdate(riderId, latitude, longitude) {
    try {
        await fetch(`${API_BASE_URL}/riders/${riderId}/location`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ latitude: String(latitude), longitude: String(longitude) })
        });
    } catch (error) {
        console.error('Error sending location:', error);
    }
}

// Start watching the browser's GPS and pushing updates while the rider is online.
function startLocationTracking(riderId) {
    if (!navigator.geolocation || locationWatchId !== null) return;

    locationWatchId = navigator.geolocation.watchPosition(
        (position) => {
            sendLocationUpdate(riderId, position.coords.latitude, position.coords.longitude);
        },
        (error) => console.warn('Location tracking error:', error.message),
        { enableHighAccuracy: true, maximumAge: 15000, timeout: 20000 }
    );
}

// Stop watching the browser's GPS (called when the rider goes offline).
function stopLocationTracking() {
    if (locationWatchId !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(locationWatchId);
        locationWatchId = null;
    }
}

// ============================================
// EARNINGS MANAGEMENT
// ============================================

// Get rider earnings
async function getRiderEarnings() {
    try {
        const user = getCurrentUser();
        if (!user) return null;
        
        const deliveries = await getRiderDeliveries();
        
        const completedDeliveries = deliveries.filter(d => d.status === 'DELIVERED');
        const totalEarnings = completedDeliveries.reduce((sum, d) => sum + (d.deliveryFee || 0), 0);
        const totalDeliveries = completedDeliveries.length;
        const averageEarning = totalDeliveries > 0 ? totalEarnings / totalDeliveries : 0;
        
        return {
            totalEarnings: totalEarnings,
            totalDeliveries: totalDeliveries,
            averageEarning: averageEarning,
            todayEarnings: completedDeliveries
                .filter(d => isToday(new Date(d.deliveryTime)))
                .reduce((sum, d) => sum + (d.deliveryFee || 0), 0)
        };
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

// Get delivery fee
function calculateDeliveryFee(distanceKm) {
    const feePerKm = 20; // Taka per km
    return distanceKm * feePerKm;
}

// ============================================
// RATING MANAGEMENT
// ============================================

// Get rider rating
async function getRiderRating() {
    try {
        const user = getCurrentUser();
        if (!user) return null;
        
        const response = await fetch(`${API_BASE_URL}/riders/rating/${user.riderId}`);
        if (!response.ok) throw new Error('Failed to fetch rating');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

// Get rider reviews
async function getRiderReviews() {
    try {
        const user = getCurrentUser();
        if (!user) return [];
        
        const response = await fetch(`${API_BASE_URL}/riders/reviews/${user.riderId}`);
        if (!response.ok) throw new Error('Failed to fetch reviews');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
}

// ============================================
// AUTHENTICATION
// ============================================

async function riderSignup(name, email, password, phone, address) {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/signup/rider`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password, phone, address })
        });
        const data = await response.json();
        if (response.ok) {
            return { success: true, user: data };
        }
        return { success: false, error: 'Email already exists' };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function riderLogin(email, password) {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/login?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        const data = await response.json();
        if (response.ok && data.role === 'RIDER') {
            localStorage.setItem('currentUser', JSON.stringify(data));
            return { success: true, user: data };
        }
        return { success: false, error: 'Invalid credentials' };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

// ============================================
// HELPER FUNCTIONS
// ============================================

function getCurrentUser() {
    const user = localStorage.getItem('currentUser');
    return user ? JSON.parse(user) : null;
}

function checkRiderAccess() {
    const user = getCurrentUser();
    if (!user || user.role !== 'RIDER') {
        alert('Rider access required');
        window.location.href = '../index.html';
    }
}

function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = '../index.html';
}

function formatPrice(price) {
    return '৳ ' + price.toFixed(2);
}

function formatDate(dateString) {
    const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    return new Date(dateString).toLocaleDateString('en-US', options);
}

function isToday(date) {
    const today = new Date();
    return date.getDate() === today.getDate() &&
           date.getMonth() === today.getMonth() &&
           date.getFullYear() === today.getFullYear();
}

// Initialize rider page
document.addEventListener('DOMContentLoaded', function() {
    checkRiderAccess();
});