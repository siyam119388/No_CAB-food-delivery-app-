// ============================================
// NoCap Frontend - Admin Dashboard JavaScript
// ============================================

// API_BASE_URL is declared once in auth.js (loaded before this file on
// every admin page) — redeclaring it here would throw
// "Identifier 'API_BASE_URL' has already been declared" since <script>
// tags on the same page share one global scope for const/let.

// ============================================
// VERIFICATION MANAGEMENT
// ============================================

// Get all pending verifications
async function getPendingVerifications() {
    try {
        const response = await fetch(`${API_BASE_URL}/admin/verifications/pending`);
        if (!response.ok) throw new Error('Failed to fetch verifications');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
}

// Approve restaurant verification
async function approveVerification(restaurantId) {
    try {
        const user = getCurrentUser();
        const response = await fetch(`${API_BASE_URL}/admin/verify/${restaurantId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ adminId: user.id, status: 'APPROVED' })
        });
        if (!response.ok) throw new Error('Failed to approve');
        alert('Restaurant approved!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error approving restaurant');
    }
}

// Reject restaurant verification
async function rejectVerification(restaurantId, reason) {
    try {
        const user = getCurrentUser();
        const response = await fetch(`${API_BASE_URL}/admin/verify/${restaurantId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ adminId: user.id, status: 'REJECTED', rejectionReason: reason })
        });
        if (!response.ok) throw new Error('Failed to reject');
        alert('Restaurant rejected!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error rejecting restaurant');
    }
}

// ============================================
// HYGIENE MONITORING
// ============================================

// Get all hygiene checks
async function getAllHygieneChecks() {
    try {
        const response = await fetch(`${API_BASE_URL}/admin/hygiene-checks`);
        if (!response.ok) throw new Error('Failed to fetch hygiene checks');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
}

// Get hygiene checks by restaurant
async function getRestaurantHygieneChecks(restaurantId) {
    try {
        const response = await fetch(`${API_BASE_URL}/admin/hygiene-checks/restaurant/${restaurantId}`);
        if (!response.ok) throw new Error('Failed to fetch checks');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
}

// Flag a hygiene check as failed
async function flagHygieneCheck(checkId) {
    try {
        const response = await fetch(`${API_BASE_URL}/admin/hygiene-checks/${checkId}/flag`, {
            method: 'PUT'
        });
        if (!response.ok) throw new Error('Failed to flag check');
        alert('Hygiene check flagged!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error flagging check');
    }
}

// ============================================
// USER MANAGEMENT
// ============================================

// Get all users
async function getAllUsers() {
    try {
        const response = await fetch(`${API_BASE_URL}/admin/users`);
        if (!response.ok) throw new Error('Failed to fetch users');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
}

// Suspend user
async function suspendUser(userId) {
    try {
        const user = getCurrentUser();
        const response = await fetch(`${API_BASE_URL}/admin/users/${userId}/suspend`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ adminId: user.id })
        });
        if (!response.ok) throw new Error('Failed to suspend user');
        alert('User suspended!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error suspending user');
    }
}

// Activate user
async function activateUser(userId) {
    try {
        const user = getCurrentUser();
        const response = await fetch(`${API_BASE_URL}/admin/users/${userId}/activate`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ adminId: user.id })
        });
        if (!response.ok) throw new Error('Failed to activate user');
        alert('User activated!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error activating user');
    }
}

// ============================================
// REVIEW MANAGEMENT
// ============================================

// Get all flagged reviews
async function getFlaggedReviews() {
    try {
        const response = await fetch(`${API_BASE_URL}/admin/reviews/flagged`);
        if (!response.ok) throw new Error('Failed to fetch flagged reviews');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
}

// Remove review
async function removeReview(reviewId) {
    try {
        const user = getCurrentUser();
        const response = await fetch(`${API_BASE_URL}/admin/reviews/${reviewId}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ adminId: user.id })
        });
        if (!response.ok) throw new Error('Failed to remove review');
        alert('Review removed!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error removing review');
    }
}

// ============================================
// RIDER MANAGEMENT
// ============================================

// Get all riders
async function getAllRiders() {
    try {
        const response = await fetch(`${API_BASE_URL}/admin/riders`);
        if (!response.ok) throw new Error('Failed to fetch riders');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
}

// Approve rider
async function approveRider(riderId) {
    try {
        const user = getCurrentUser();
        const response = await fetch(`${API_BASE_URL}/riders/approve/${riderId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ adminId: user.id })
        });
        if (!response.ok) throw new Error('Failed to approve rider');
        alert('Rider approved!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error approving rider');
    }
}

// Reject rider
async function rejectRider(riderId) {
    try {
        const user = getCurrentUser();
        const response = await fetch(`${API_BASE_URL}/riders/reject/${riderId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ adminId: user.id })
        });
        if (!response.ok) throw new Error('Failed to reject rider');
        alert('Rider rejected!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error rejecting rider');
    }
}

// ============================================
// ANALYTICS
// ============================================

// Get dashboard statistics
async function getDashboardStats() {
    try {
        const stats = {
            totalOrders: 0,
            totalRestaurants: 0,
            totalRiders: 0,
            totalUsers: 0,
            complianceRate: 0
        };
        
        // You can fetch individual stats from different endpoints
        const restaurants = await fetch(`${API_BASE_URL}/restaurants`).then(r => r.json());
        const riders = await getAllRiders();
        const users = await getAllUsers();
        
        stats.totalRestaurants = restaurants.length;
        stats.totalRiders = riders.length;
        stats.totalUsers = users.length;
        
        return stats;
    } catch (error) {
        console.error('Error fetching stats:', error);
        return null;
    }
}

// ============================================
// HELPER FUNCTIONS
// ============================================

function getCurrentUser() {
    const user = localStorage.getItem('currentUser');
    return user ? JSON.parse(user) : null;
}

function checkAdminAccess() {
    const user = getCurrentUser();
    if (!user || user.role !== 'ADMIN') {
        alert('Admin access required');
        window.location.href = '../index.html';
    }
}

function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = '../index.html';
}

// Initialize admin page
document.addEventListener('DOMContentLoaded', function() {
    checkAdminAccess();
});

// ============================================
// DASHBOARD SCREEN
// ============================================

async function loadAdminDashboard() {
    const restaurants = await fetch(`${API_BASE_URL}/restaurants`).then(r => r.json()).catch(() => []);
    const pending = await getPendingVerifications();
    const orders = await fetch(`${API_BASE_URL}/admin/orders`).then(r => r.json()).catch(() => []);
    const users = await getAllUsers();
    const flagged = await getFlaggedReviews();
    const hygieneChecks = await getAllHygieneChecks();

    const customers = users.filter(u => u.role === "CUSTOMER");
    const verified = restaurants.filter(r => r.status === "APPROVED");

    document.getElementById("customerCount").textContent = customers.length;
    document.getElementById("verifiedCount").textContent = verified.length;
    document.getElementById("orderCount").textContent = orders.length;
    document.getElementById("pendingCount").textContent = pending.length;

    if (pending.length > 0) {
        const box = document.getElementById("pendingAlert");
        box.classList.remove("hide");
        document.getElementById("pendingAlertText").textContent = pending.length + " restaurant(s) awaiting review";
    }

    const suspended = restaurants.filter(r => r.status === "SUSPENDED");
    if (suspended.length > 0) {
        const box = document.getElementById("hygieneAlert");
        box.classList.remove("hide");
        document.getElementById("hygieneAlertText").textContent = suspended.length + " restaurant(s) suspended";
    }

    if (flagged.length > 0) {
        const box = document.getElementById("flagAlert");
        box.classList.remove("hide");
        document.getElementById("flagAlertText").textContent = flagged.length + " review(s) flagged";
    }

    const scores = verified.map(r => r.hygieneScore || 0);
    const avg = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
    document.getElementById("avgScore").textContent = avg;
    document.getElementById("atRisk").textContent = verified.filter(r => (r.hygieneScore || 0) < 75).length;
    document.getElementById("suspended").textContent = suspended.length;
    document.getElementById("flagCount").textContent = flagged.length;
}


// ============================================
// HYGIENE MONITORING SCREEN
// ============================================

async function loadAdminHygiene() {
    const restaurants = await fetch(`${API_BASE_URL}/restaurants`).then(r => r.json()).catch(() => []);
    const approved = restaurants.filter(r => r.status === "APPROVED" || r.status === "SUSPENDED");

    const scores = approved.map(r => r.hygieneScore || 0);
    const avg = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;

    document.getElementById("avg").textContent = avg;
    document.getElementById("avgBar").style.width = avg + "%";
    document.getElementById("tracked").textContent = approved.length + " TRACKED";

    const safe = approved.filter(r => (r.hygieneScore || 0) >= 85);
    const risk = approved.filter(r => (r.hygieneScore || 0) < 75);

    document.getElementById("safe").textContent = safe.length;
    document.getElementById("risk").textContent = risk.length;

    const scoresBox = document.getElementById("scores");
    scoresBox.innerHTML = "";
    approved.forEach(r => {
        const row = document.createElement("div");
        row.className = "li";
        row.innerHTML = `<span>${r.name}</span><span>${r.hygieneScore || 0}/100 ${r.status === "SUSPENDED" ? "\u26d4" : ""}</span>`;
        scoresBox.appendChild(row);
    });

    const riskBox = document.getElementById("riskBox");
    riskBox.innerHTML = "";
    risk.forEach(r => {
        const card = document.createElement("div");
        card.className = "card card-accent";
        card.innerHTML = `
            <div class="row">
                <span>${r.name} \u2014 score ${r.hygieneScore || 0}</span>
                <button class="btn-red btn-sm" data-id="${r.id}">Suspend now</button>
            </div>
        `;
        riskBox.appendChild(card);
    });

    riskBox.querySelectorAll("button").forEach(btn => {
        btn.addEventListener("click", async () => {
            const checks = await getRestaurantHygieneChecks(btn.dataset.id);
            const latest = checks[0];
            if (latest) {
                await flagHygieneCheck(latest.id);
            } else {
                alert("No hygiene check on record for this restaurant yet.");
            }
        });
    });
}


// ============================================
// FAKE REVIEW DETECTION SCREEN
// ============================================

async function loadFakeReviews() {
    const flagged = await getFlaggedReviews();

    document.getElementById("flagged").textContent = flagged.length;

    const list = document.getElementById("list");
    list.innerHTML = "";

    if (flagged.length === 0) {
        list.innerHTML = "<p style='text-align:center;color:#999'>No flagged reviews right now</p>";
        return;
    }

    flagged.forEach(row => {
        const card = document.createElement("div");
        card.className = "card card-accent";
        card.innerHTML = `
            <div class="name">Rating: ${row.rating || "-"}/5 \u2022 Confidence ${row.confidence}%</div>
            <div class="sub">${row.comment || "(no comment)"}</div>
            <div class="small">Signals: ${row.signals || "-"}</div>
            <div class="btnrow" style="margin-top:8px">
                <button class="btn-out btn-sm" data-action="keep" data-id="${row.reviewId}">Keep</button>
                <button class="btn-red btn-sm" data-action="remove" data-id="${row.reviewId}">Remove</button>
            </div>
        `;
        list.appendChild(card);
    });

    list.querySelectorAll('[data-action="remove"]').forEach(btn => {
        btn.addEventListener("click", () => removeReview(btn.dataset.id));
    });

    list.querySelectorAll('[data-action="keep"]').forEach(btn => {
        btn.addEventListener("click", async () => {
            const user = getCurrentUser();
            await fetch(`${API_BASE_URL}/admin/reviews/${btn.dataset.id}/keep`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ adminId: user.id })
            });
            location.reload();
        });
    });
}


// ============================================
// VERIFICATION QUEUE SCREEN
// ============================================

async function loadQueue() {
    const pending = await getPendingVerifications();
    const queue = document.getElementById("queue");
    queue.innerHTML = "";

    if (pending.length === 0) {
        queue.innerHTML = "<p style='text-align:center;color:#999'>Nothing pending</p>";
        return;
    }

    pending.forEach(r => {
        const card = document.createElement("div");
        card.className = "card";
        card.style.cursor = "pointer";
        card.onclick = () => window.location.href = `verify-detail.html?id=${r.id}`;
        card.innerHTML = `
            <div class="row">
                <div>
                    <div class="name">${r.name}</div>
                    <div class="sub">${r.cuisine || ""} \u2022 ${r.address || ""}</div>
                </div>
                <span class="badge b-blue">PENDING</span>
            </div>
        `;
        queue.appendChild(card);
    });
}


// ============================================
// VERIFY DETAIL SCREEN
// ============================================

async function loadVerifyDetail() {
    const id = new URLSearchParams(window.location.search).get("id");

    if (!id) {
        window.location.href = "verification.html";
        return;
    }

    const restaurant = await fetch(`${API_BASE_URL}/restaurants/${id}`).then(r => r.json()).catch(() => null);

    if (!restaurant) {
        alert("Restaurant not found");
        window.location.href = "verification.html";
        return;
    }

    document.getElementById("title").textContent = restaurant.name;
    document.getElementById("sub").textContent = restaurant.cuisine || "";

    const pct = restaurant.status === "PENDING" ? 50 : 100;
    document.getElementById("pct").textContent = pct + "%";
    document.getElementById("pctBar").style.width = pct + "%";
    document.getElementById("stageText").textContent =
        restaurant.status === "PENDING" ? "Documents submitted, awaiting your decision." : restaurant.status;

    document.getElementById("stages").innerHTML = `
        <div class="li"><span>\u2705 Documents submitted</span></div>
        <div class="li"><span>\u23f3 Admin decision</span></div>
    `;

    const actions = document.getElementById("actions");
    actions.innerHTML = `
        <div class="btnrow">
            <button class="btn" id="approveBtn">Approve</button>
            <button class="btn-red" id="rejectBtn">Reject</button>
        </div>
    `;

    document.getElementById("approveBtn").addEventListener("click", async () => {
        await approveVerification(id);
    });

    document.getElementById("rejectBtn").addEventListener("click", async () => {
        const reason = prompt("Reason for rejection?") || "";
        await rejectVerification(id, reason);
    });
}
