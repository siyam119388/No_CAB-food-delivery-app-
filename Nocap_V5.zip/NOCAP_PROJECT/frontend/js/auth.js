// ============================================================
// NoCap - Authentication
// Supports:
// CUSTOMER
// RESTAURANT_OWNER
// ADMIN
// RIDER
// ============================================================

const API_BASE_URL = "http://localhost:8080/api";


// ============================================================
// COMMON HELPERS
// ============================================================

function saveCurrentUser(user) {
    localStorage.setItem(
        "currentUser",
        JSON.stringify(user)
    );
}


function getCurrentUser() {
    try {
        const user = localStorage.getItem("currentUser");

        return user
            ? JSON.parse(user)
            : null;

    } catch (error) {

        console.error(
            "Could not read current user:",
            error
        );

        return null;
    }
}


function clearCurrentUser() {
    localStorage.removeItem("currentUser");
}


function logout() {

    clearCurrentUser();

    localStorage.removeItem("cart");

    window.location.href =
        getIndexPath();
}


function getIndexPath() {

    const path =
        window.location.pathname;

    /*
     * Rider / Restaurant / Admin pages
     * are inside subfolders.
     */

    if (
        path.includes("/rider/") ||
        path.includes("/restaurant/") ||
        path.includes("/admin/")
    ) {
        return "../index.html";
    }

    return "index.html";
}


function normalizeRole(role) {

    if (!role) {
        return "";
    }

    const value =
        String(role)
            .trim()
            .toUpperCase();

    /*
     * Backend's real restaurant role.
     */

    if (
        value === "RESTAURANT" ||
        value === "RESTAURANT_OWNER"
    ) {
        return "RESTAURANT_OWNER";
    }

    return value;
}


async function readResponse(response) {

    const text =
        await response.text();

    if (!text) {
        return {};
    }

    try {
        return JSON.parse(text);

    } catch (error) {

        return {
            message: text
        };
    }
}


function getErrorMessage(data, fallback) {

    if (!data) {
        return fallback;
    }

    if (typeof data === "string") {
        return data;
    }

    return (
        data.error ||
        data.message ||
        fallback
    );
}


// ============================================================
// CUSTOMER SIGNUP
// ============================================================

async function customerSignup(
    name,
    email,
    password,
    phone,
    address
) {

    try {

        const response =
            await fetch(
                `${API_BASE_URL}/auth/signup/customer`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({
                        name,
                        email,
                        password,
                        phone,
                        address
                    })
                }
            );


        const data =
            await readResponse(response);


        if (!response.ok) {

            return {
                success: false,
                error: getErrorMessage(
                    data,
                    "Customer signup failed."
                )
            };
        }


        const user = {
            ...data,
            role:
                normalizeRole(
                    data.role
                )
        };


        saveCurrentUser(user);


        return {
            success: true,
            user
        };

    } catch (error) {

        console.error(
            "Customer signup error:",
            error
        );

        return {
            success: false,
            error:
                "Cannot connect to backend. " +
                error.message
        };
    }
}


// ============================================================
// CUSTOMER LOGIN
// ============================================================

async function customerLogin(
    email,
    password
) {

    return loginWithRole(
        email,
        password,
        "CUSTOMER"
    );
}


// ============================================================
// ADMIN SIGNUP
// ============================================================

async function adminSignup(
    name,
    email,
    password,
    phone,
    address
) {

    try {

        const response =
            await fetch(
                `${API_BASE_URL}/auth/signup/admin`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({
                        name,
                        email,
                        password,
                        phone,
                        address
                    })
                }
            );


        const data =
            await readResponse(response);


        if (!response.ok) {

            return {
                success: false,
                error: getErrorMessage(
                    data,
                    "Admin signup failed."
                )
            };
        }


        const user = {
            ...data,
            role:
                normalizeRole(
                    data.role
                )
        };


        saveCurrentUser(user);


        return {
            success: true,
            user
        };

    } catch (error) {

        console.error(
            "Admin signup error:",
            error
        );

        return {
            success: false,
            error:
                "Cannot connect to backend. " +
                error.message
        };
    }
}


// ============================================================
// RESTAURANT SIGNUP
// ============================================================

// ============================================================
// BROWSER GEOLOCATION HELPER
// ============================================================
//
// Resolves to { latitude, longitude } (as strings) or null if the
// user denies permission / the browser doesn't support it. Used at
// restaurant signup and rider signup so new accounts show up
// correctly on the nearby-restaurant / delivery maps immediately.
//
function getBrowserLocation() {

    return new Promise((resolve) => {

        if (!navigator.geolocation) {
            resolve(null);
            return;
        }

        navigator.geolocation.getCurrentPosition(
            (position) => {
                resolve({
                    latitude: String(position.coords.latitude),
                    longitude: String(position.coords.longitude)
                });
            },
            () => resolve(null),
            { timeout: 8000 }
        );
    });
}


async function restaurantSignup(
    name,
    email,
    password,
    phone,
    address,
    restaurantName,
    cuisine
) {

    try {

        const location =
            await getBrowserLocation();

        const response =
            await fetch(
                `${API_BASE_URL}/auth/signup/restaurant`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({
                        name,
                        email,
                        password,
                        phone,
                        address,
                        restaurantName,
                        cuisine,
                        latitude: location ? location.latitude : null,
                        longitude: location ? location.longitude : null
                    })
                }
            );


        const data =
            await readResponse(response);


        if (!response.ok) {

            return {
                success: false,
                error: getErrorMessage(
                    data,
                    "Restaurant signup failed."
                )
            };
        }


        const user = {
            ...data,
            role:
                normalizeRole(
                    data.role
                )
        };


        saveCurrentUser(user);


        return {
            success: true,
            user
        };

    } catch (error) {

        console.error(
            "Restaurant signup error:",
            error
        );

        return {
            success: false,
            error:
                "Cannot connect to backend. " +
                error.message
        };
    }
}


// ============================================================
// RESTAURANT LOGIN
// ============================================================

async function restaurantLogin(
    email,
    password
) {

    return loginWithRole(
        email,
        password,
        "RESTAURANT_OWNER"
    );
}


// ============================================================
// RIDER SIGNUP
// ============================================================

async function riderSignup(
    name,
    email,
    password,
    phone,
    address
) {

    try {

        const response =
            await fetch(
                `${API_BASE_URL}/auth/signup/rider`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({
                        name,
                        email,
                        password,
                        phone,
                        address
                    })
                }
            );


        const data =
            await readResponse(response);


        if (!response.ok) {

            return {
                success: false,
                error: getErrorMessage(
                    data,
                    "Rider signup failed."
                )
            };
        }


        const user = {
            ...data,
            role:
                normalizeRole(
                    data.role
                )
        };


        /*
         * Rider account is created successfully.
         *
         * Backend creates the Rider profile with
         * PENDING status.
         */

        saveCurrentUser(user);


        return {
            success: true,
            user
        };

    } catch (error) {

        console.error(
            "Rider signup error:",
            error
        );

        return {
            success: false,
            error:
                "Cannot connect to backend. " +
                error.message
        };
    }
}


// ============================================================
// RIDER LOGIN
// ============================================================

async function riderLogin(
    email,
    password
) {

    return loginWithRole(
        email,
        password,
        "RIDER"
    );
}


// ============================================================
// ADMIN LOGIN
// ============================================================

async function adminLogin(
    email,
    password
) {

    return loginWithRole(
        email,
        password,
        "ADMIN"
    );
}


// ============================================================
// GENERIC LOGIN
// ============================================================

async function loginWithRole(
    email,
    password,
    expectedRole
) {

    try {

        const url =
            `${API_BASE_URL}/auth/login` +
            `?email=${encodeURIComponent(email)}` +
            `&password=${encodeURIComponent(password)}`;


        const response =
            await fetch(
                url,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    }
                }
            );


        const data =
            await readResponse(response);


        if (!response.ok) {

            return {
                success: false,
                error: getErrorMessage(
                    data,
                    "Invalid email or password."
                )
            };
        }


        if (!data || !data.role) {

            return {
                success: false,
                error:
                    "Backend did not return a user role."
            };
        }


        const actualRole =
            normalizeRole(
                data.role
            );


        const requiredRole =
            normalizeRole(
                expectedRole
            );


        /*
         * IMPORTANT:
         *
         * Customer -> CUSTOMER
         * Restaurant -> RESTAURANT_OWNER
         * Admin -> ADMIN
         * Rider -> RIDER
         */

        if (
            actualRole !== requiredRole
        ) {

            return {
                success: false,

                error:
                    "This account belongs to " +
                    getRoleName(actualRole) +
                    ", not " +
                    getRoleName(requiredRole) +
                    "."
            };
        }


        const user = {
            ...data,
            role: actualRole
        };


        saveCurrentUser(user);


        return {
            success: true,
            user
        };

    } catch (error) {

        console.error(
            "Login error:",
            error
        );


        return {
            success: false,

            error:
                "Cannot connect to backend. " +
                error.message
        };
    }
}


// ============================================================
// ROLE NAME
// ============================================================

function getRoleName(role) {

    switch (
        normalizeRole(role)
    ) {

        case "CUSTOMER":
            return "Customer";

        case "RESTAURANT_OWNER":
            return "Restaurant";

        case "ADMIN":
            return "Admin";

        case "RIDER":
            return "Rider";

        default:
            return "Unknown role";
    }
}


// ============================================================
// ROLE CHECK
// ============================================================

function isLoggedIn() {

    return getCurrentUser() !== null;
}


function hasRole(requiredRole) {

    const user =
        getCurrentUser();


    if (!user) {
        return false;
    }


    return (
        normalizeRole(
            user.role
        ) ===
        normalizeRole(
            requiredRole
        )
    );
}


// ============================================================
// PAGE ACCESS CHECKS
// ============================================================

// ============================================================
// REQUIRE ROLE
// ============================================================
//
// Used directly by page <script> blocks, e.g.:
//   if (requireRole("CUSTOMER")) { loadHome(); }
//   const u = requireRole("CUSTOMER");
//   if (requireRole("ADMIN", "login.html")) { ... }
//
// Returns the current user object if the role matches, otherwise
// redirects and returns null (falsy, so `if (requireRole(...))`
// checks work the same way as `if (requireRole(...) !== null)`).
//
function requireRole(role, redirectPath) {

    const user =
        getCurrentUser();

    if (
        !user ||
        normalizeRole(user.role) !== normalizeRole(role)
    ) {

        window.location.href =
            redirectPath || getIndexPath();

        return null;
    }

    return user;
}


// ============================================================
// THROWING-STYLE WRAPPERS
// ============================================================
//
// A couple of screens (admin/login.html, restaurant/register.html)
// call a function that resolves on success or throws on failure,
// instead of the {success, error} object style used elsewhere.
//

async function login(email, password, role) {

    const result = await loginWithRole(email, password, role);

    if (!result.success) {
        throw new Error(result.error || "Login failed.");
    }

    return result.user;
}


async function registerRestaurant(data) {

    const result = await restaurantSignup(
        data.ownerName || data.name || "",
        data.email,
        data.password,
        data.phone || "",
        data.address || "",
        data.restaurantName || "",
        data.cuisine || ""
    );

    if (!result.success) {
        throw new Error(result.error || "Restaurant registration failed.");
    }

    return result.user;
}


function checkCustomerAccess() {

    const user =
        getCurrentUser();


    if (!user) {

        window.location.href =
            getIndexPath();

        return false;
    }


    if (
        normalizeRole(user.role)
        !== "CUSTOMER"
    ) {

        alert(
            "Customer access required."
        );

        window.location.href =
            getIndexPath();

        return false;
    }


    return true;
}


function checkRestaurantAccess() {

    const user =
        getCurrentUser();


    if (!user) {

        window.location.href =
            getIndexPath();

        return false;
    }


    if (
        normalizeRole(user.role)
        !== "RESTAURANT_OWNER"
    ) {

        alert(
            "Restaurant owner access required."
        );

        window.location.href =
            getIndexPath();

        return false;
    }


    return true;
}


function checkAdminAccess() {

    const user =
        getCurrentUser();


    if (!user) {

        window.location.href =
            getIndexPath();

        return false;
    }


    if (
        normalizeRole(user.role)
        !== "ADMIN"
    ) {

        alert(
            "Admin access required."
        );

        window.location.href =
            getIndexPath();

        return false;
    }


    return true;
}


function checkRiderAccess() {

    const user =
        getCurrentUser();


    if (!user) {

        window.location.href =
            "../index.html";

        return false;
    }


    if (
        normalizeRole(user.role)
        !== "RIDER"
    ) {

        alert(
            "Rider access required."
        );

        window.location.href =
            "../index.html";

        return false;
    }


    return true;
}


// ============================================================
// LOGIN REDIRECT
// ============================================================

function getDashboardForRole(role) {

    switch (
        normalizeRole(role)
    ) {

        case "CUSTOMER":
            return "home.html";

        case "RESTAURANT_OWNER":
            return "restaurant/dashboard.html";

        case "ADMIN":
            return "admin/dashboard.html";

        case "RIDER":
            return "rider/dashboard.html";

        default:
            return "index.html";
    }
}


// ============================================================
// GENERIC LOGIN FORM
// ============================================================
//
// This function is kept because some existing pages
// may still call handleLogin().
//

async function handleLogin(event) {

    event.preventDefault();


    const email =
        document
            .getElementById("email")
            ?.value
            .trim();


    const password =
        document
            .getElementById("password")
            ?.value
            .trim();


    const roleElement =
        document.getElementById("role");


    const role =
        roleElement
            ? roleElement.value
            : "";


    if (
        !email ||
        !password ||
        !role
    ) {

        alert(
            "Please enter email, password and role."
        );

        return;
    }


    let result;


    if (role === "customer") {

        result =
            await customerLogin(
                email,
                password
            );

    }

    else if (
        role === "restaurant" ||
        role === "restaurant_owner"
    ) {

        result =
            await restaurantLogin(
                email,
                password
            );

    }

    else if (role === "admin") {

        result =
            await adminLogin(
                email,
                password
            );

    }

    else if (role === "rider") {

        result =
            await riderLogin(
                email,
                password
            );

    }

    else {

        alert(
            "Invalid role selected."
        );

        return;
    }


    if (!result.success) {

        alert(
            "Login failed: " +
            result.error
        );

        return;
    }


    window.location.href =
        getDashboardForRole(
            result.user.role
        );
}


// ============================================================
// CUSTOMER SIGNUP HANDLER
// ============================================================

async function handleCustomerSignup(
    event
) {

    event.preventDefault();


    const name =
        document
            .getElementById("name")
            .value
            .trim();


    const email =
        document
            .getElementById("email")
            .value
            .trim();


    const password =
        document
            .getElementById("password")
            .value
            .trim();


    const phone =
        document
            .getElementById("phone")
            .value
            .trim();


    const address =
        document
            .getElementById("address")
            .value
            .trim();


    if (
        !name ||
        !email ||
        !password ||
        !phone ||
        !address
    ) {

        alert(
            "Please fill all fields."
        );

        return;
    }


    const result =
        await customerSignup(
            name,
            email,
            password,
            phone,
            address
        );


    if (!result.success) {

        alert(
            "Signup failed: " +
            result.error
        );

        return;
    }


    alert(
        "Customer signup successful!"
    );


    window.location.href =
        "home.html";
}


// ============================================================
// RESTAURANT SIGNUP HANDLER
// ============================================================

async function handleRestaurantSignup(
    event
) {

    event.preventDefault();


    const name =
        document
            .getElementById("name")
            .value
            .trim();


    const email =
        document
            .getElementById("email")
            .value
            .trim();


    const password =
        document
            .getElementById("password")
            .value
            .trim();


    const phone =
        document
            .getElementById("phone")
            .value
            .trim();


    const address =
        document
            .getElementById("address")
            .value
            .trim();


    if (
        !name ||
        !email ||
        !password ||
        !phone ||
        !address
    ) {

        alert(
            "Please fill all fields."
        );

        return;
    }


    const result =
        await restaurantSignup(
            name,
            email,
            password,
            phone,
            address
        );


    if (!result.success) {

        alert(
            "Signup failed: " +
            result.error
        );

        return;
    }


    alert(
        "Restaurant signup successful!"
    );


    window.location.href =
        "restaurant/dashboard.html";
}


// ============================================================
// RIDER SIGNUP HANDLER
// ============================================================

async function handleRiderSignup(
    event
) {

    event.preventDefault();


    const name =
        document
            .getElementById("name")
            .value
            .trim();


    const email =
        document
            .getElementById("email")
            .value
            .trim();


    const password =
        document
            .getElementById("password")
            .value
            .trim();


    const phone =
        document
            .getElementById("phone")
            .value
            .trim();


    const address =
        document
            .getElementById("address")
            .value
            .trim();


    if (
        !name ||
        !email ||
        !password ||
        !phone ||
        !address
    ) {

        alert(
            "Please fill all fields."
        );

        return;
    }


    if (password.length < 6) {

        alert(
            "Password must be at least 6 characters."
        );

        return;
    }


    const result =
        await riderSignup(
            name,
            email,
            password,
            phone,
            address
        );


    if (!result.success) {

        alert(
            "Rider signup failed: " +
            result.error
        );

        return;
    }


    alert(
        "Rider account created successfully!\n\n" +
        "Your rider profile is currently pending approval."
    );


    /*
     * Do NOT send rider directly to dashboard
     * while account is still pending.
     *
     * Go back to login.
     */

    window.location.href =
        "../index.html";
}


// ============================================================
// PAGE AUTO ACCESS CHECK
// ============================================================
//
// These checks are intentionally only triggered if the page
// explicitly declares a matching body data attribute.
//
// Example:
//
// <body data-role-page="RIDER">
//
// This avoids breaking existing HTML pages.
//

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const body =
            document.body;


        if (!body) {
            return;
        }


        const rolePage =
            body.dataset.rolePage;


        if (!rolePage) {
            return;
        }


        switch (
            normalizeRole(rolePage)
        ) {

            case "CUSTOMER":
                checkCustomerAccess();
                break;

            case "RESTAURANT_OWNER":
                checkRestaurantAccess();
                break;

            case "ADMIN":
                checkAdminAccess();
                break;

            case "RIDER":
                checkRiderAccess();
                break;
        }
    }
);