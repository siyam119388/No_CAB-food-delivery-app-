// ============================================
// NoCap Frontend - Restaurant Owner JavaScript
// ============================================

// API_BASE_URL is declared once in auth.js (loaded before this file on
// every restaurant page) — redeclaring it here would throw
// "Identifier 'API_BASE_URL' has already been declared" since <script>
// tags on the same page share one global scope for const/let.

// ============================================
// RESTAURANT MANAGEMENT
// ============================================

// Get restaurant details
async function getRestaurantProfile() {
    try {
        const user = getCurrentUser();
        if (!user || !user.restaurantId) return null;
        
        const response = await fetch(`${API_BASE_URL}/restaurants/${user.restaurantId}`);
        if (!response.ok) throw new Error('Failed to fetch restaurant');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

// Update restaurant details
async function updateRestaurantProfile(restaurantId, data) {
    try {
        const response = await fetch(`${API_BASE_URL}/restaurants/${restaurantId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if (!response.ok) throw new Error('Failed to update restaurant');
        alert('Restaurant updated successfully!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error updating restaurant');
    }
}

// ============================================
// MENU MANAGEMENT
// ============================================

// Get all menu items for restaurant
async function getRestaurantMenu() {
    try {
        const user = getCurrentUser();
        if (!user || !user.restaurantId) return [];
        
        const response = await fetch(`${API_BASE_URL}/menu-items/restaurant/${user.restaurantId}`);
        if (!response.ok) throw new Error('Failed to fetch menu');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
}

// Add menu item
async function addMenuItem(restaurantId, name, description, price, category, imageUrl) {
    try {
        const response = await fetch(`${API_BASE_URL}/menu-items`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                restaurantId: restaurantId,
                name: name,
                description: description,
                price: price,
                category: category,
                available: true,
                imageUrl: imageUrl || null
            })
        });
        if (!response.ok) throw new Error('Failed to add menu item');
        alert('Menu item added!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error adding menu item');
    }
}

// Update menu item
async function updateMenuItem(itemId, name, description, price, category, isAvailable) {
    try {
        const response = await fetch(`${API_BASE_URL}/menu-items/${itemId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: name,
                description: description,
                price: price,
                category: category,
                available: isAvailable
            })
        });
        if (!response.ok) throw new Error('Failed to update menu item');
        alert('Menu item updated!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error updating menu item');
    }
}

// Delete menu item
async function deleteMenuItem(itemId) {
    try {
        if (!confirm('Are you sure you want to delete this item?')) return;
        
        const response = await fetch(`${API_BASE_URL}/menu-items/${itemId}`, {
            method: 'DELETE'
        });
        if (!response.ok) throw new Error('Failed to delete menu item');
        alert('Menu item deleted!');
        location.reload();
    } catch (error) {
        console.error('Error:', error);
        alert('Error deleting menu item');
    }
}

// ============================================
// ORDER MANAGEMENT
// ============================================

// Get restaurant orders
async function getRestaurantOrders() {
    try {
        const user = getCurrentUser();
        if (!user || !user.restaurantId) return [];
        
        const response = await fetch(`${API_BASE_URL}/orders/restaurant/${user.restaurantId}`);
        if (!response.ok) throw new Error('Failed to fetch orders');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
}

// Update order status
async function updateOrderStatus(orderId, status) {
    try {
        const response = await fetch(`${API_BASE_URL}/orders/${orderId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: status })
        });
        if (!response.ok) throw new Error('Failed to update order');
        alert('Order status updated!');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error updating order status');
    }
}

// Accept order
async function acceptOrder(orderId) {
    return updateOrderStatus(orderId, 'ACCEPTED');
}

// Reject order
async function rejectOrder(orderId) {
    return updateOrderStatus(orderId, 'REJECTED');
}

// Mark as preparing
async function markPreparing(orderId) {
    return updateOrderStatus(orderId, 'PREPARING');
}

// Mark as ready
async function markReady(orderId) {
    return updateOrderStatus(orderId, 'READY');
}

// ============================================
// HYGIENE MANAGEMENT
// ============================================

// Get hygiene score
async function getHygieneScore() {
    try {
        const user = getCurrentUser();
        if (!user || !user.restaurantId) return null;
        
        const response = await fetch(`${API_BASE_URL}/hygiene/restaurant/${user.restaurantId}/score`);
        if (!response.ok) throw new Error('Failed to fetch hygiene score');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

// Get hygiene checks
async function getHygieneChecks() {
    try {
        const user = getCurrentUser();
        if (!user || !user.restaurantId) return [];
        
        const response = await fetch(`${API_BASE_URL}/hygiene/restaurant/${user.restaurantId}/checks`);
        if (!response.ok) throw new Error('Failed to fetch checks');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
}

// Submit hygiene photo
async function submitHygienePhoto(checkId, photoUrl) {
    try {
        const response = await fetch(`${API_BASE_URL}/hygiene/checks/${checkId}/submit`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ photoUrl: photoUrl })
        });
        if (!response.ok) throw new Error('Failed to submit photo');
        alert('Photo submitted! AI analysis in progress...');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error submitting photo');
    }
}

// Appeal hygiene check failure
async function appealHygieneCheck(checkId, reason) {
    try {
        const response = await fetch(`${API_BASE_URL}/hygiene/checks/${checkId}/appeal`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ appealReason: reason })
        });
        if (!response.ok) throw new Error('Failed to appeal');
        alert('Appeal submitted! Awaiting admin review...');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error submitting appeal');
    }
}

// ============================================
// VERIFICATION MANAGEMENT
// ============================================

// Get verification status
async function getVerificationStatus() {
    try {
        const user = getCurrentUser();
        if (!user || !user.restaurantId) return null;
        
        const response = await fetch(`${API_BASE_URL}/verification/restaurant/${user.restaurantId}`);
        if (!response.ok) throw new Error('Failed to fetch verification status');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

// Upload verification documents
async function uploadVerificationDoc(restaurantId, docType, fileUrl) {
    try {
        const response = await fetch(`${API_BASE_URL}/documents`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                restaurantId: restaurantId,
                documentType: docType,
                documentUrl: fileUrl,
                status: 'PENDING'
            })
        });
        if (!response.ok) throw new Error('Failed to upload document');
        alert('Document uploaded! Awaiting verification...');
        location.reload();
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        alert('Error uploading document');
    }
}

// ============================================
// SALES & ANALYTICS
// ============================================

// Get sales data
async function getSalesData() {
    try {
        const user = getCurrentUser();
        if (!user) return null;
        
        const orders = await getRestaurantOrders();
        
        const totalOrders = orders.length;
        const totalRevenue = orders
            .filter(o => o.status === 'DELIVERED')
            .reduce((sum, o) => sum + (Number(o.total) || 0), 0);
        const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
        
        return {
            totalOrders: totalOrders,
            totalRevenue: totalRevenue,
            averageOrderValue: averageOrderValue,
            completionRate: totalOrders > 0 ? (orders.filter(o => o.status === 'DELIVERED').length / totalOrders * 100).toFixed(2) : 0
        };
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

// ============================================
// HELPER FUNCTIONS
// ============================================

function getCurrentUser() {
    const user = localStorage.getItem('currentUser');
    return user ? JSON.parse(user) : null;
}

function checkRestaurantAccess() {
    const user = getCurrentUser();
    if (!user || user.role !== 'RESTAURANT_OWNER') {
        alert('Restaurant access required');
        window.location.href = '../index.html';
    }
}

function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = '../index.html';
}

function formatPrice(price) {
    return '৳ ' + price.toFixed(2);
}

function formatDate(dateString) {
    const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    return new Date(dateString).toLocaleDateString('en-US', options);
}

// Initialize restaurant page
document.addEventListener('DOMContentLoaded', function() {
    checkRestaurantAccess();
});

// ============================================
// DASHBOARD SCREEN
// ============================================

async function loadOwnerDashboard() {
    const user = getCurrentUser();
    if (!user) return;

    const restaurant = await getRestaurantProfile();
    if (restaurant) {
        const nameEl = document.getElementById("restName");
        if (nameEl) nameEl.textContent = restaurant.name;

        document.getElementById("score").textContent = restaurant.hygieneScore || 0;
        document.getElementById("scoreBar").style.width = (restaurant.hygieneScore || 0) + "%";
        document.getElementById("rating").textContent = restaurant.rating || 0;

        const statusBadge = document.getElementById("statusBadge");
        const statusNote = document.getElementById("statusNote");
        if (restaurant.status === "APPROVED") {
            statusBadge.textContent = "\u2705 VERIFIED";
        } else if (restaurant.status === "PENDING") {
            statusBadge.textContent = "\u23f3 PENDING";
            statusNote.textContent = "Awaiting admin verification";
        } else if (restaurant.status === "SUSPENDED") {
            statusBadge.textContent = "\u26d4 SUSPENDED";
            statusNote.textContent = "Suspended for repeated hygiene failures";
        } else if (restaurant.status === "REJECTED") {
            statusBadge.textContent = "\u274c REJECTED";
        }
    }

    const orders = await getRestaurantOrders();
    const delivered = orders.filter(o => o.status === "DELIVERED");
    const active = orders.filter(o => !["DELIVERED", "CANCELLED"].includes(o.status));

    document.getElementById("ordersToday").textContent = orders.length;
    document.getElementById("salesToday").textContent = formatPrice(
        delivered.reduce((sum, o) => sum + (Number(o.total) || 0), 0)
    );
    document.getElementById("pendingOrders").textContent = active.length;

    if (active.length > 0) {
        const alertBox = document.getElementById("orderAlert");
        if (alertBox) {
            alertBox.classList.remove("hide");
            document.getElementById("orderAlertText").textContent = active.length + " order(s) need attention";
        }
    }

    const menu = await getRestaurantMenu();
    const menuCount = document.getElementById("menuCount");
    if (menuCount) menuCount.textContent = menu.length + " items \u203a";
}


// ============================================
// MENU MANAGEMENT SCREEN
// ============================================

async function loadOwnerMenu() {
    const items = await getRestaurantMenu();
    renderOwnerMenu(items);

    const addBtn = document.getElementById("addBtn");
    const addForm = document.getElementById("addForm");

    addBtn.addEventListener("click", () => {
        addForm.classList.toggle("hide");
    });

    document.getElementById("saveItem").addEventListener("click", async () => {
        const user = getCurrentUser();
        const name = document.getElementById("itemName").value.trim();
        const price = parseFloat(document.getElementById("itemPrice").value);
        const category = document.getElementById("itemCat").value.trim();
        const description = document.getElementById("itemDesc").value.trim();
        const imageInput = document.getElementById("itemImage");
        const errBox = document.getElementById("itemErr");

        errBox.textContent = "";

        if (!user || !user.restaurantId) {
            errBox.textContent = "Could not find your restaurant on this account \u2014 please log out and log back in.";
            return;
        }

        if (!name || !price) {
            errBox.textContent = "Name and price are required.";
            return;
        }

        const saveBtn = document.getElementById("saveItem");
        saveBtn.disabled = true;
        saveBtn.textContent = "Saving...";

        const imageUrl = await uploadImageFile(imageInput);

        await addMenuItem(user.restaurantId, name, description, price, category, imageUrl);
    });
}

function renderOwnerMenu(items) {
    const container = document.getElementById("menuList");
    container.innerHTML = "";

    if (!items || items.length === 0) {
        container.innerHTML = "<p style='text-align:center;color:#999'>No menu items yet</p>";
        return;
    }

    items.forEach(item => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
            <div class="row">
                ${item.imageUrl ? `<img src="${item.imageUrl}" style="width:56px;height:56px;object-fit:cover;border-radius:10px;margin-right:10px">` : ""}
                <div>
                    <div class="name">${item.name}</div>
                    <div class="sub">${item.category || ""} \u2022 ${formatPrice(item.price)}</div>
                </div>
                <span class="badge ${item.available ? "b-green" : "b-blue"}">
                    ${item.available ? "Available" : "Sold out"}
                </span>
            </div>
            <div class="btnrow" style="margin-top:8px">
                <button class="btn-out btn-sm" data-action="toggle" data-id="${item.id}">
                    ${item.available ? "Mark sold out" : "Mark available"}
                </button>
                <button class="btn-red btn-sm" data-action="delete" data-id="${item.id}">Delete</button>
            </div>
        `;
        container.appendChild(card);
    });

    container.querySelectorAll('[data-action="toggle"]').forEach(btn => {
        btn.addEventListener("click", () => {
            const item = items.find(i => String(i.id) === btn.dataset.id);
            updateMenuItem(item.id, item.name, item.description, item.price, item.category, !item.available);
        });
    });

    container.querySelectorAll('[data-action="delete"]').forEach(btn => {
        btn.addEventListener("click", () => deleteMenuItem(btn.dataset.id));
    });
}


// ============================================
// ORDER MANAGEMENT SCREEN
// ============================================

const ORDER_ACTIONS = {
    PLACED: { next: "ACCEPTED", label: "Accept order" },
    ACCEPTED: { next: "PREPARING", label: "Start preparing" },
    PREPARING: { next: "OUT_FOR_DELIVERY", label: "Ready for pickup" }
};

async function loadOwnerOrders() {
    const orders = await getRestaurantOrders();
    const container = document.getElementById("orderList");
    container.innerHTML = "";

    if (!orders || orders.length === 0) {
        container.innerHTML = "<p style='text-align:center;color:#999'>No orders yet</p>";
        return;
    }

    orders.forEach(order => {
        const card = document.createElement("div");
        card.className = "card";

        const action = ORDER_ACTIONS[order.status];

        card.innerHTML = `
            <div class="row">
                <div>
                    <div class="name">Order #${order.id}</div>
                    <div class="sub">${order.status} \u2022 ${formatPrice(order.total || 0)}</div>
                </div>
            </div>
            <div class="btnrow" style="margin-top:8px">
                ${action ? `<button class="btn btn-sm" data-action="advance" data-id="${order.id}" data-status="${action.next}">${action.label}</button>` : ""}
                ${order.status === "PLACED" ? `<button class="btn-red btn-sm" data-action="reject" data-id="${order.id}">Reject</button>` : ""}
            </div>
        `;
        container.appendChild(card);
    });

    container.querySelectorAll('[data-action="advance"]').forEach(btn => {
        btn.addEventListener("click", () => updateOrderStatus(btn.dataset.id, btn.dataset.status));
    });

    container.querySelectorAll('[data-action="reject"]').forEach(btn => {
        btn.addEventListener("click", () => updateOrderStatus(btn.dataset.id, "CANCELLED"));
    });
}


// ============================================
// HYGIENE SCREEN
// ============================================

async function loadHygiene() {
    const user = getCurrentUser();
    if (!user || !user.restaurantId) return;

    const checks = await getHygieneChecks();
    const uploadBox = document.getElementById("uploadBox");
    const pendingBox = document.getElementById("pendingBox");
    const noPending = document.getElementById("noPending");
    const failWarn = document.getElementById("failWarn");
    const history = document.getElementById("history");

    const pendingCheck = checks.find(c => !c.uploadedAt);

    if (pendingCheck) {
        pendingBox.classList.remove("hide");
        uploadBox.classList.remove("hide");
        noPending.classList.add("hide");

        document.getElementById("uploadBtn").onclick = async () => {
            const fileInput = document.getElementById("hygienePhotoInput");

            if (!fileInput.files || fileInput.files.length === 0) {
                alert("Please choose a photo first.");
                return;
            }

            const uploadBtn = document.getElementById("uploadBtn");
            uploadBtn.disabled = true;
            uploadBtn.textContent = "Uploading...";

            const photoUrl = await uploadImageFile(fileInput);

            if (!photoUrl) {
                uploadBtn.disabled = false;
                uploadBtn.textContent = "Upload Photo";
                return;
            }

            await submitHygienePhoto(pendingCheck.id, photoUrl);
        };
    } else {
        pendingBox.classList.add("hide");
        uploadBox.classList.add("hide");
        noPending.classList.remove("hide");

        const requestBtn = document.getElementById("requestCheckBtn");
        requestBtn.classList.remove("hide");
        requestBtn.onclick = async () => {
            const user = getCurrentUser();
            if (!user || !user.restaurantId) return;

            requestBtn.disabled = true;
            requestBtn.textContent = "Requesting...";

            try {
                await fetch(`${API_BASE_URL}/hygiene/restaurant/${user.restaurantId}/request`, { method: "POST" });
                location.reload();
            } catch (err) {
                console.error(err);
                alert("\u274c Could not request a check \u2014 is the backend running?");
                requestBtn.disabled = false;
                requestBtn.textContent = "Request a hygiene check now";
            }
        };
    }

    const recentFails = checks.filter(c => c.passed === false).length;
    failWarn.innerHTML = recentFails >= 2
        ? `<div class="small">\u26a0\ufe0f ${recentFails} recent failed check(s). One more fail may suspend your restaurant.</div>`
        : "";

    history.innerHTML = "";
    checks.forEach(check => {
        const row = document.createElement("div");
        row.className = "li";
        row.innerHTML = `
            <span>${new Date(check.requestedAt).toLocaleDateString()}</span>
            <span>${check.passed === null ? "Pending" : check.passed ? "\u2705 Passed" : "\u274c Failed"} ${check.score != null ? "(" + check.score + ")" : ""}</span>
        `;
        history.appendChild(row);
    });
}


// ============================================
// VERIFICATION SCREEN
// ============================================

const VERIFICATION_STAGES = ["PENDING", "APPROVED"];

async function loadVerification() {
    const status = await getVerificationStatus();
    if (!status) return;

    const pct = status.status === "APPROVED" ? 100 : status.status === "REJECTED" ? 100 : 50;

    document.getElementById("pct").textContent = pct + "%";
    document.getElementById("pctBar").style.width = pct + "%";
    document.getElementById("stageText").textContent =
        status.status === "APPROVED" ? "Your restaurant is live on NoCap." :
        status.status === "REJECTED" ? "Your application was rejected." :
        "Awaiting admin review.";

    if (status.status === "REJECTED") {
        document.getElementById("noteBox").classList.remove("hide");
    }

    const stages = document.getElementById("stages");
    stages.innerHTML = `
        <div class="li"><span>\u2705 Documents submitted</span></div>
        <div class="li"><span>${status.status === "APPROVED" ? "\u2705" : "\u23f3"} Admin review</span></div>
        <div class="li"><span>${status.status === "APPROVED" ? "\u2705" : "\u25cb"} Live on NoCap</span></div>
    `;

    const docList = document.getElementById("docList");
    docList.innerHTML = "";
    (status.documents || []).forEach(doc => {
        const row = document.createElement("div");
        row.className = "li";
        row.innerHTML = `<span>${doc.type}</span><span class="sub">${doc.status}</span>`;
        docList.appendChild(row);
    });
}
