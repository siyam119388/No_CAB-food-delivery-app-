package com.nocap.controller;

import com.nocap.model.Rider;
import com.nocap.model.Restaurant;
import com.nocap.model.User;
import com.nocap.service.AuthService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthService authService;


    // ============================================================
    // CUSTOMER SIGNUP
    // ============================================================

    @PostMapping("/signup/customer")
    public ResponseEntity<?> customerSignup(
        @RequestBody SignupRequest request
    ) {

        try {

            User user =
                buildUser(request);


            User saved =
                authService.customerSignup(
                    user
                );


            return ResponseEntity.ok(
                buildUserResponse(saved)
            );

        } catch (Exception e) {

            return badRequest(
                e.getMessage()
            );
        }
    }


    // ============================================================
    // RESTAURANT SIGNUP
    // ============================================================

    @PostMapping("/signup/restaurant")
    public ResponseEntity<?> restaurantSignup(
        @RequestBody SignupRequest request
    ) {

        try {

            User user =
                buildUser(request);


            User saved =
                authService.restaurantSignup(
                    user,
                    request.getRestaurantName(),
                    request.getCuisine(),
                    request.getLatitude(),
                    request.getLongitude()
                );


            Map<String, Object> response =
                buildUserResponse(saved);


            /*
             * Return restaurant information too.
             */

            Restaurant restaurant =
                authService
                    .getRestaurantByOwnerId(
                        saved.getId()
                    );


            if (restaurant != null) {

                response.put(
                    "restaurantId",
                    restaurant.getId()
                );

                response.put(
                    "restaurantName",
                    restaurant.getName()
                );

                response.put(
                    "cuisine",
                    restaurant.getCuisine()
                );

                response.put(
                    "restaurantStatus",
                    restaurant.getStatus()
                );
            }


            return ResponseEntity.ok(
                response
            );

        } catch (Exception e) {

            return badRequest(
                e.getMessage()
            );
        }
    }


    // ============================================================
    // ADMIN SIGNUP
    // ============================================================

    @PostMapping("/signup/admin")
    public ResponseEntity<?> adminSignup(
        @RequestBody SignupRequest request
    ) {

        try {

            User user =
                buildUser(request);


            User saved =
                authService.adminSignup(
                    user
                );


            return ResponseEntity.ok(
                buildUserResponse(saved)
            );

        } catch (Exception e) {

            return badRequest(
                e.getMessage()
            );
        }
    }


    // ============================================================
    // RIDER SIGNUP
    // ============================================================

    @PostMapping("/signup/rider")
    public ResponseEntity<?> riderSignup(
        @RequestBody SignupRequest request
    ) {

        try {

            User user =
                buildUser(request);


            String nid =
                request.getNid();


            User saved =
                authService.riderSignup(
                    user,
                    nid
                );


            Map<String, Object> response =
                buildUserResponse(saved);


            /*
             * Return rider profile information.
             */

            Rider rider =
                authService
                    .getRiderByUserId(
                        saved.getId()
                    );


            if (rider != null) {

                response.put(
                    "riderId",
                    rider.getId()
                );

                response.put(
                    "riderStatus",
                    rider.getStatus()
                );

                response.put(
                    "isOnline",
                    rider.getIsOnline()
                );
            }


            return ResponseEntity.ok(
                response
            );

        } catch (Exception e) {

            return badRequest(
                e.getMessage()
            );
        }
    }


    // ============================================================
    // LOGIN
    // ============================================================

    @PostMapping("/login")
    public ResponseEntity<?> login(
        @RequestParam String email,
        @RequestParam String password
    ) {

        try {

            User user =
                authService.login(
                    email,
                    password
                );


            if (user == null) {

                return badRequest(
                    "Invalid email or password."
                );
            }


            Map<String, Object> response =
                buildUserResponse(user);


            /*
             * If rider, return rider profile info.
             */

            if (
                user.getRole() ==
                User.Role.RIDER
            ) {

                Rider rider =
                    authService
                        .getRiderByUserId(
                            user.getId()
                        );


                if (rider != null) {

                    response.put(
                        "riderId",
                        rider.getId()
                    );

                    response.put(
                        "riderStatus",
                        rider.getStatus()
                    );

                    response.put(
                        "isOnline",
                        rider.getIsOnline()
                    );
                }
            }


            /*
             * If restaurant owner,
             * return restaurant info.
             */

            if (
                user.getRole() ==
                User.Role.RESTAURANT_OWNER
            ) {

                Restaurant restaurant =
                    authService
                        .getRestaurantByOwnerId(
                            user.getId()
                        );


                if (restaurant != null) {

                    response.put(
                        "restaurantId",
                        restaurant.getId()
                    );

                    response.put(
                        "restaurantName",
                        restaurant.getName()
                    );

                    response.put(
                        "cuisine",
                        restaurant.getCuisine()
                    );

                    response.put(
                        "restaurantStatus",
                        restaurant.getStatus()
                    );
                }
            }


            return ResponseEntity.ok(
                response
            );

        } catch (Exception e) {

            return badRequest(
                e.getMessage()
            );
        }
    }


    // ============================================================
    // GET USER
    // ============================================================

    @GetMapping("/user/{id}")
    public ResponseEntity<?> getUser(
        @PathVariable Long id
    ) {

        User user =
            authService.getUserById(id);


        if (user == null) {

            return ResponseEntity
                .notFound()
                .build();
        }


        return ResponseEntity.ok(
            buildUserResponse(user)
        );
    }


    // ============================================================
    // BUILD USER
    // ============================================================

    private User buildUser(
        SignupRequest request
    ) {

        User user =
            new User();


        user.setName(
            request.getName()
        );


        user.setEmail(
            request.getEmail()
        );


        user.setPassword(
            request.getPassword()
        );


        user.setPhone(
            request.getPhone()
        );


        user.setAddress(
            request.getAddress()
        );


        return user;
    }


    // ============================================================
    // USER RESPONSE
    // ============================================================

    private Map<String, Object>
    buildUserResponse(
        User user
    ) {

        Map<String, Object> response =
            new HashMap<>();


        response.put(
            "id",
            user.getId()
        );


        response.put(
            "name",
            user.getName()
        );


        response.put(
            "email",
            user.getEmail()
        );


        response.put(
            "role",
            user.getRole()
        );


        response.put(
            "phone",
            user.getPhone()
        );


        response.put(
            "address",
            user.getAddress()
        );


        return response;
    }


    // ============================================================
    // ERROR RESPONSE
    // ============================================================

    private ResponseEntity<?> badRequest(
        String message
    ) {

        Map<String, String> error =
            new HashMap<>();


        error.put(
            "error",
            message != null
                ? message
                : "Request failed."
        );


        return ResponseEntity
            .badRequest()
            .body(error);
    }
}