package com.nocap.controller;

import com.nocap.model.Restaurant;
import com.nocap.service.RestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/restaurants")
@CrossOrigin(origins = "*")
public class RestaurantController {

    @Autowired
    private RestaurantService restaurantService;

    // Get all restaurants
    @GetMapping
    public ResponseEntity<List<Restaurant>> getAllRestaurants() {
        List<Restaurant> restaurants = restaurantService.getAllRestaurants();
        return ResponseEntity.ok(restaurants);
    }

    // Get restaurant by ID
    @GetMapping("/{id}")
    public ResponseEntity<Restaurant> getRestaurantById(@PathVariable Long id) {
        Restaurant restaurant = restaurantService.getRestaurantById(id);
        if (restaurant != null) {
            return ResponseEntity.ok(restaurant);
        }
        return ResponseEntity.notFound().build();
    }

    // Get nearby restaurants based on location
    @GetMapping("/nearby")
    public ResponseEntity<List<Restaurant>> getNearbyRestaurants(
            @RequestParam double latitude,
            @RequestParam double longitude,
            @RequestParam(defaultValue = "5") double radiusKm) {
        
        List<Restaurant> restaurants = restaurantService.getNearbyRestaurants(latitude, longitude, radiusKm);
        return ResponseEntity.ok(restaurants);
    }

    // Save restaurant
    @PostMapping
    public ResponseEntity<Restaurant> saveRestaurant(@RequestBody Restaurant restaurant) {
        Restaurant saved = restaurantService.saveRestaurant(restaurant);
        return ResponseEntity.ok(saved);
    }

    // Update restaurant profile (owner editing their own listing)
    @PutMapping("/{id}")
    public ResponseEntity<?> updateRestaurant(@PathVariable Long id, @RequestBody Restaurant update) {

        Restaurant existing = restaurantService.getRestaurantById(id);

        if (existing == null) {
            return ResponseEntity.notFound().build();
        }

        if (update.getName() != null) existing.setName(update.getName());
        if (update.getAddress() != null) existing.setAddress(update.getAddress());
        if (update.getCuisine() != null) existing.setCuisine(update.getCuisine());
        if (update.getDeliveryFee() != null) existing.setDeliveryFee(update.getDeliveryFee());
        if (update.getLatitude() != null) existing.setLatitude(update.getLatitude());
        if (update.getLongitude() != null) existing.setLongitude(update.getLongitude());

        return ResponseEntity.ok(restaurantService.saveRestaurant(existing));
    }

    // Delete restaurant
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteRestaurant(@PathVariable Long id) {
        restaurantService.deleteRestaurant(id);
        return ResponseEntity.ok("Restaurant deleted");
    }
}