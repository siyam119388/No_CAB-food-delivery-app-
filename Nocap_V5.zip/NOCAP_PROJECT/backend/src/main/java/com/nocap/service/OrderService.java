package com.nocap.service;

import com.nocap.model.Delivery;
import com.nocap.model.MenuItem;
import com.nocap.model.Order;
import com.nocap.model.OrderItem;
import com.nocap.model.Restaurant;
import com.nocap.repository.MenuItemRepository;
import com.nocap.repository.OrderItemRepository;
import com.nocap.repository.OrderRepository;
import com.nocap.repository.RestaurantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * OrderService
 *
 * - placeOrder(...)   save order + order items, status PLACED
 * - updateStatus(...) owner accepts / prepares / marks out for delivery
 *                      (creates the Delivery row the rider app polls for
 *                      the moment status becomes OUT_FOR_DELIVERY)
 * - getCustomerOrders(customerId) / getRestaurantOrders(restaurantId)
 */
@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    @Autowired
    private MenuItemRepository menuItemRepository;

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Autowired
    private DeliveryService deliveryService;


    /**
     * items: list of maps with keys menuItemId, quantity (name/price are
     * looked up server-side from the menu item so a tampered client
     * request can't change prices).
     */
    public Order placeOrder(
        Long customerId,
        Long restaurantId,
        List<Map<String, Object>> items,
        String address,
        String paymentMethod
    ) {
        return placeOrder(customerId, restaurantId, items, address, paymentMethod, null, null);
    }


    /**
     * Same as above, but with the customer's live delivery coordinates
     * (captured via browser geolocation at checkout). When both the
     * customer's position and the restaurant's registered position are
     * known, the delivery fee is distance-based (Haversine × rate/km)
     * instead of the restaurant's flat fee.
     */
    public Order placeOrder(
        Long customerId,
        Long restaurantId,
        List<Map<String, Object>> items,
        String address,
        String paymentMethod,
        Double deliveryLat,
        Double deliveryLng
    ) {

        if (customerId == null || restaurantId == null) {
            throw new IllegalArgumentException("customerId and restaurantId are required.");
        }

        if (items == null || items.isEmpty()) {
            throw new IllegalArgumentException("Cart is empty.");
        }

        Restaurant restaurant =
            restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new IllegalArgumentException("Restaurant not found."));

        BigDecimal subtotal = BigDecimal.ZERO;
        List<OrderItem> orderItems = new ArrayList<>();

        for (Map<String, Object> item : items) {

            Long menuItemId = Long.valueOf(String.valueOf(item.get("menuItemId")));
            int quantity = Integer.parseInt(String.valueOf(item.getOrDefault("quantity", 1)));

            MenuItem menuItem =
                menuItemRepository.findById(menuItemId)
                    .orElseThrow(() -> new IllegalArgumentException("Menu item " + menuItemId + " not found."));

            BigDecimal lineTotal = menuItem.getPrice().multiply(BigDecimal.valueOf(quantity));
            subtotal = subtotal.add(lineTotal);

            OrderItem orderItem = new OrderItem();
            orderItem.setMenuItemId(menuItemId);
            orderItem.setQuantity(quantity);
            orderItem.setPrice(menuItem.getPrice());
            orderItems.add(orderItem);
        }

        BigDecimal deliveryFee =
            restaurant.getDeliveryFee() != null
                ? restaurant.getDeliveryFee()
                : new BigDecimal("50.00");

        Double distanceKm = distanceKmIfKnown(restaurant, deliveryLat, deliveryLng);

        if (distanceKm != null) {
            deliveryFee = new BigDecimal(String.valueOf(20.0 * distanceKm))
                .setScale(2, java.math.RoundingMode.HALF_UP);
        }

        Order order = new Order();
        order.setCustomerId(customerId);
        order.setRestaurantId(restaurantId);
        order.setSubtotal(subtotal);
        order.setDeliveryFee(deliveryFee);
        order.setTotal(subtotal.add(deliveryFee));
        order.setAddress(address);

        if (deliveryLat != null) {
            order.setDeliveryLat(String.valueOf(deliveryLat));
        }
        if (deliveryLng != null) {
            order.setDeliveryLng(String.valueOf(deliveryLng));
        }
        order.setStatus(Order.Status.PLACED);

        if (paymentMethod != null && paymentMethod.trim().equalsIgnoreCase("BKASH")) {
            order.setPaymentMethod(Order.Payment.BKASH);
        } else {
            order.setPaymentMethod(Order.Payment.COD);
        }

        Order savedOrder = orderRepository.save(order);

        for (OrderItem orderItem : orderItems) {
            orderItem.setOrderId(savedOrder.getId());
            orderItemRepository.save(orderItem);
        }

        return savedOrder;
    }


    /** Straight-line distance (km) between the restaurant and the delivery point, if both are known. */
    private Double distanceKmIfKnown(Restaurant restaurant, Double deliveryLat, Double deliveryLng) {

        if (deliveryLat == null || deliveryLng == null) {
            return null;
        }

        if (restaurant.getLatitude() == null || restaurant.getLongitude() == null) {
            return null;
        }

        try {
            double restLat = Double.parseDouble(restaurant.getLatitude());
            double restLng = Double.parseDouble(restaurant.getLongitude());

            final int earthRadiusKm = 6371;

            double latDist = Math.toRadians(deliveryLat - restLat);
            double lngDist = Math.toRadians(deliveryLng - restLng);

            double a = Math.sin(latDist / 2) * Math.sin(latDist / 2)
                + Math.cos(Math.toRadians(restLat)) * Math.cos(Math.toRadians(deliveryLat))
                * Math.sin(lngDist / 2) * Math.sin(lngDist / 2);

            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

            return earthRadiusKm * c;

        } catch (NumberFormatException e) {
            return null;
        }
    }


    public Order updateStatus(Long orderId, String statusValue) {

        Order order =
            orderRepository.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found."));

        Order.Status newStatus = parseStatus(statusValue);

        order.setStatus(newStatus);
        Order saved = orderRepository.save(order);

        /*
         * The moment the restaurant marks the order OUT_FOR_DELIVERY,
         * a Delivery row is created so it shows up in the rider app's
         * "available deliveries" list.
         */
        if (newStatus == Order.Status.OUT_FOR_DELIVERY) {

            Delivery existing = deliveryService.getDeliveryByOrderId(saved.getId());

            if (existing == null) {

                Double fee =
                    saved.getDeliveryFee() != null
                        ? saved.getDeliveryFee().doubleValue()
                        : 50.0;

                Restaurant restaurant = restaurantRepository.findById(saved.getRestaurantId()).orElse(null);
                Double distanceKm = restaurant != null
                    ? distanceKmIfKnown(
                        restaurant,
                        saved.getDeliveryLat() != null ? Double.valueOf(saved.getDeliveryLat()) : null,
                        saved.getDeliveryLng() != null ? Double.valueOf(saved.getDeliveryLng()) : null)
                    : null;

                deliveryService.createDelivery(saved, fee, distanceKm);
            }
        }

        return saved;
    }


    /** Accepts common aliases used by different screens (READY -> OUT_FOR_DELIVERY, REJECTED -> CANCELLED). */
    private Order.Status parseStatus(String value) {

        if (value == null) {
            throw new IllegalArgumentException("status is required.");
        }

        String normalized = value.trim().toUpperCase();

        switch (normalized) {
            case "READY":
                normalized = "OUT_FOR_DELIVERY";
                break;
            case "REJECTED":
                normalized = "CANCELLED";
                break;
            default:
                break;
        }

        try {
            return Order.Status.valueOf(normalized);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Unknown order status: " + value);
        }
    }


    public Order getOrderById(Long orderId) {
        return orderRepository.findById(orderId).orElse(null);
    }


    public List<OrderItem> getOrderItems(Long orderId) {
        return orderItemRepository.findByOrderId(orderId);
    }


    public List<Order> getCustomerOrders(Long customerId) {
        return orderRepository.findByCustomerIdOrderByCreatedAtDesc(customerId);
    }


    public List<Order> getRestaurantOrders(Long restaurantId) {
        return orderRepository.findByRestaurantIdOrderByCreatedAtDesc(restaurantId);
    }
}
