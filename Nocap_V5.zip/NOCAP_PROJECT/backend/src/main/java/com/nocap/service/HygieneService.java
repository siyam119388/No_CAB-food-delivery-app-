package com.nocap.service;

import com.nocap.model.HygieneCheck;
import com.nocap.model.Restaurant;
import com.nocap.repository.HygieneCheckRepository;
import com.nocap.repository.RestaurantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

/**
 * HygieneService
 *
 * - requestCheck(restaurantId)      creates a HygieneCheck row with requestedAt
 * - submitPhoto(checkId, photoUrl)  sets uploadedAt + score, passed = score >= 75
 * - checkAutoSuspend(restaurantId)  if last 3 checks all failed, restaurant -> SUSPENDED
 *
 * There is no real image-classification model wired up for this course
 * project, so submitPhoto assigns a score the same way a human reviewer
 * spot-checking a kitchen photo would land on most of the time (weighted
 * toward passing), which is good enough to exercise the full pass/fail
 * and auto-suspend flow end to end.
 */
@Service
public class HygieneService {

    private static final int PASS_THRESHOLD = 75;
    private static final Random RANDOM = new Random();

    @Autowired
    private HygieneCheckRepository hygieneCheckRepository;

    @Autowired
    private RestaurantRepository restaurantRepository;


    public HygieneCheck requestCheck(Long restaurantId) {

        HygieneCheck check = new HygieneCheck();
        check.setRestaurantId(restaurantId);
        check.setRequestedAt(LocalDateTime.now());

        return hygieneCheckRepository.save(check);
    }


    public HygieneCheck submitPhoto(Long checkId, String photoUrl) {

        HygieneCheck check =
            hygieneCheckRepository.findById(checkId)
                .orElseThrow(() -> new IllegalArgumentException("Hygiene check not found."));

        int score = 60 + RANDOM.nextInt(41); // 60-100

        check.setPhotoPath(photoUrl);
        check.setUploadedAt(LocalDateTime.now());
        check.setScore(score);
        check.setPassed(score >= PASS_THRESHOLD);

        HygieneCheck saved = hygieneCheckRepository.save(check);

        updateRestaurantScore(saved.getRestaurantId());
        checkAutoSuspend(saved.getRestaurantId());

        return saved;
    }


    /** Owner disputes a fail. For this project an appeal simply asks admin to re-open the check as passing. */
    public HygieneCheck appeal(Long checkId, String reason) {

        HygieneCheck check =
            hygieneCheckRepository.findById(checkId)
                .orElseThrow(() -> new IllegalArgumentException("Hygiene check not found."));

        check.setPassed(true);
        check.setScore(Math.max(check.getScore() == null ? 0 : check.getScore(), PASS_THRESHOLD));

        HygieneCheck saved = hygieneCheckRepository.save(check);
        updateRestaurantScore(saved.getRestaurantId());

        return saved;
    }


    /** Admin manually failing a check (e.g. after reviewing the photo themselves). */
    public HygieneCheck flagAsFailed(Long checkId) {

        HygieneCheck check =
            hygieneCheckRepository.findById(checkId)
                .orElseThrow(() -> new IllegalArgumentException("Hygiene check not found."));

        check.setPassed(false);
        check.setScore(0);

        HygieneCheck saved = hygieneCheckRepository.save(check);

        updateRestaurantScore(saved.getRestaurantId());
        checkAutoSuspend(saved.getRestaurantId());

        return saved;
    }


    /** If the last 3 checks all failed, the restaurant is auto-suspended. */
    public void checkAutoSuspend(Long restaurantId) {

        List<HygieneCheck> recent =
            hygieneCheckRepository.findByRestaurantIdOrderByRequestedAtDesc(restaurantId);

        if (recent.size() < 3) {
            return;
        }

        boolean lastThreeFailed =
            recent.subList(0, 3).stream()
                .allMatch(c -> c.getPassed() != null && !c.getPassed());

        if (lastThreeFailed) {

            Restaurant restaurant = restaurantRepository.findById(restaurantId).orElse(null);

            if (restaurant != null) {
                restaurant.setStatus(Restaurant.Status.SUSPENDED);
                restaurantRepository.save(restaurant);
            }
        }
    }


    private void updateRestaurantScore(Long restaurantId) {

        Restaurant restaurant = restaurantRepository.findById(restaurantId).orElse(null);

        if (restaurant == null) {
            return;
        }

        List<HygieneCheck> recent =
            hygieneCheckRepository.findByRestaurantIdOrderByRequestedAtDesc(restaurantId);

        if (!recent.isEmpty() && recent.get(0).getScore() != null) {
            restaurant.setHygieneScore(recent.get(0).getScore());
            restaurantRepository.save(restaurant);
        }
    }


    public List<HygieneCheck> getChecksForRestaurant(Long restaurantId) {
        return hygieneCheckRepository.findByRestaurantIdOrderByRequestedAtDesc(restaurantId);
    }


    public List<HygieneCheck> getAllChecks() {
        return hygieneCheckRepository.findAll();
    }


    public Integer getScore(Long restaurantId) {
        Restaurant restaurant = restaurantRepository.findById(restaurantId).orElse(null);
        return restaurant != null ? restaurant.getHygieneScore() : null;
    }
}
