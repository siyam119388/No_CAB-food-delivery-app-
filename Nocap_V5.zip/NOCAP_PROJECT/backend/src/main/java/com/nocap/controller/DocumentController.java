package com.nocap.controller;

import com.nocap.service.VerificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/documents")
@CrossOrigin(origins = "*")
public class DocumentController {

    @Autowired
    private VerificationService verificationService;

    // restaurant.js -> POST /api/documents
    // body: { restaurantId, documentType, documentUrl, status }
    @PostMapping
    public ResponseEntity<?> uploadDocument(@RequestBody Map<String, Object> body) {

        try {
            Long restaurantId = Long.valueOf(String.valueOf(body.get("restaurantId")));
            String type = String.valueOf(body.get("documentType"));
            String url = String.valueOf(body.get("documentUrl"));

            return ResponseEntity.ok(verificationService.uploadDocument(restaurantId, type, url));

        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage() != null ? e.getMessage() : "Upload failed.");
            return ResponseEntity.badRequest().body(error);
        }
    }
}
