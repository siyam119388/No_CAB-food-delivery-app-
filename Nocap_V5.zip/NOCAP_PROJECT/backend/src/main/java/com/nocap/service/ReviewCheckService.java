package com.nocap.service;

import com.nocap.model.Order;
import com.nocap.model.Review;
import com.nocap.model.ReviewFlag;
import com.nocap.model.User;
import com.nocap.repository.OrderRepository;
import com.nocap.repository.ReviewFlagRepository;
import com.nocap.repository.ReviewRepository;
import com.nocap.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * ReviewCheckService
 *
 * - submitReview(orderId, rating, comment)  reject unless order is DELIVERED
 * - scoreReview(review)                     sum the weights of the signals that fire:
 *       no linked / undelivered order .... 40   (enforced before save, so this never fires here)
 *       comment length < 20 chars ........ 25
 *       duplicate comment text ........... 20
 *       account younger than 24 hours .... 15
 *   if score > 70 -> save ReviewFlag and hide the review pending admin decision
 */
@Service
public class ReviewCheckService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private ReviewFlagRepository reviewFlagRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;


    public Review submitReview(Long orderId, Integer rating, String comment) {

        Order order =
            orderRepository.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found."));

        if (order.getStatus() != Order.Status.DELIVERED) {
            throw new IllegalArgumentException("You can only review an order after it has been delivered.");
        }

        if (reviewRepository.existsByOrderId(orderId)) {
            throw new IllegalArgumentException("You already reviewed this order.");
        }

        Review review = new Review();
        review.setOrderId(orderId);
        review.setCustomerId(order.getCustomerId());
        review.setRestaurantId(order.getRestaurantId());
        review.setRating(rating);
        review.setComment(comment);
        review.setStatus(Review.Status.VISIBLE);

        Review saved = reviewRepository.save(review);

        List<String> signals = new ArrayList<>();
        int score = scoreReview(saved, signals);

        if (score > 70) {

            saved.setStatus(Review.Status.HIDDEN);
            reviewRepository.save(saved);

            ReviewFlag flag = new ReviewFlag();
            flag.setReviewId(saved.getId());
            flag.setConfidence(score);
            flag.setSignals(String.join(",", signals));
            flag.setDecision(ReviewFlag.Decision.PENDING);

            reviewFlagRepository.save(flag);
        }

        return saved;
    }


    private int scoreReview(Review review, List<String> signals) {

        int score = 0;

        String comment = review.getComment();

        if (comment == null || comment.trim().length() < 20) {
            score += 25;
            signals.add("SHORT_COMMENT");
        }

        if (comment != null && !comment.trim().isEmpty()
                && reviewRepository.countByComment(comment) > 1) {
            score += 20;
            signals.add("DUPLICATE_COMMENT");
        }

        User customer = userRepository.findById(review.getCustomerId()).orElse(null);

        if (customer != null && customer.getCreatedAt() != null) {
            long hours = Duration.between(customer.getCreatedAt(), LocalDateTime.now()).toHours();
            if (hours < 24) {
                score += 15;
                signals.add("NEW_ACCOUNT");
            }
        }

        return score;
    }


    public List<Review> getVisibleReviews(Long restaurantId) {
        return reviewRepository.findByRestaurantIdAndStatus(restaurantId, Review.Status.VISIBLE);
    }


    public List<ReviewFlag> getPendingFlags() {
        return reviewFlagRepository.findByDecision(ReviewFlag.Decision.PENDING);
    }


    public Review keepReview(Long reviewId, Long adminId) {

        Review review =
            reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("Review not found."));

        review.setStatus(Review.Status.VISIBLE);
        Review saved = reviewRepository.save(review);

        reviewFlagRepository.findByReviewId(reviewId).ifPresent(flag -> {
            flag.setDecision(ReviewFlag.Decision.KEPT);
            flag.setDecidedBy(adminId);
            reviewFlagRepository.save(flag);
        });

        return saved;
    }


    public Review removeReview(Long reviewId, Long adminId) {

        Review review =
            reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("Review not found."));

        review.setStatus(Review.Status.REMOVED);
        Review saved = reviewRepository.save(review);

        reviewFlagRepository.findByReviewId(reviewId).ifPresent(flag -> {
            flag.setDecision(ReviewFlag.Decision.REMOVED);
            flag.setDecidedBy(adminId);
            reviewFlagRepository.save(flag);
        });

        return saved;
    }
}
