package com.nocap.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * FileUploadController
 *
 * Real image upload for menu-item photos and hygiene-check photos.
 * Files are saved to an "uploads" folder on disk (created next to
 * wherever the Spring Boot app is run from) and served back out at
 * /uploads/<filename> — see WebConfig's resource handler.
 */
@RestController
@RequestMapping("/api/uploads")
@CrossOrigin(origins = "*")
public class FileUploadController {

    private static final long MAX_FILE_SIZE = 8 * 1024 * 1024; // 8 MB

    @PostMapping
    public ResponseEntity<?> uploadFile(@RequestParam("file") MultipartFile file) {

        Map<String, String> error = new HashMap<>();

        if (file == null || file.isEmpty()) {
            error.put("error", "No file was sent.");
            return ResponseEntity.badRequest().body(error);
        }

        if (file.getSize() > MAX_FILE_SIZE) {
            error.put("error", "File is too large (max 8MB).");
            return ResponseEntity.badRequest().body(error);
        }

        String contentType = file.getContentType();
        if (contentType == null || !contentType.startsWith("image/")) {
            error.put("error", "Only image files are allowed.");
            return ResponseEntity.badRequest().body(error);
        }

        try {
            Path uploadDir = Paths.get("uploads");
            if (!Files.exists(uploadDir)) {
                Files.createDirectories(uploadDir);
            }

            String originalName = file.getOriginalFilename() != null ? file.getOriginalFilename() : "photo.jpg";
            String extension = "";
            int dot = originalName.lastIndexOf('.');
            if (dot >= 0) {
                extension = originalName.substring(dot);
            }

            String filename = UUID.randomUUID().toString() + extension;
            Path destination = uploadDir.resolve(filename);

            file.transferTo(destination.toFile());

            Map<String, String> response = new HashMap<>();
            response.put("url", "/uploads/" + filename);
            return ResponseEntity.ok(response);

        } catch (IOException e) {
            error.put("error", "Could not save file: " + e.getMessage());
            return ResponseEntity.internalServerError().body(error);
        }
    }
}
