package com.nocap.service;

import com.nocap.model.AdminAction;
import com.nocap.model.Document;
import com.nocap.model.Restaurant;
import com.nocap.repository.AdminActionRepository;
import com.nocap.repository.DocumentRepository;
import com.nocap.repository.RestaurantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * VerificationService
 *
 * - uploadDocument(restaurantId, type, filePath)   stage 1
 * - approve(restaurantId, adminId)                 status APPROVED, visible to customers
 * - reject(restaurantId, adminId, reason)           status REJECTED
 */
@Service
public class VerificationService {

    @Autowired
    private DocumentRepository documentRepository;

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Autowired
    private AdminActionRepository adminActionRepository;


    public Document uploadDocument(Long restaurantId, String type, String filePath) {

        Document document = new Document();
        document.setRestaurantId(restaurantId);
        document.setFilePath(filePath);
        document.setStatus(Document.Status.PENDING);

        try {
            document.setType(Document.Type.valueOf(type.trim().toUpperCase()));
        } catch (Exception e) {
            document.setType(Document.Type.TRADE_LICENCE);
        }

        return documentRepository.save(document);
    }


    public List<Document> getDocuments(Long restaurantId) {
        return documentRepository.findByRestaurantId(restaurantId);
    }


    public List<Restaurant> getPendingRestaurants() {
        return restaurantRepository.findByStatus(Restaurant.Status.PENDING);
    }


    public Restaurant approve(Long restaurantId, Long adminId) {

        Restaurant restaurant =
            restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new IllegalArgumentException("Restaurant not found."));

        restaurant.setStatus(Restaurant.Status.APPROVED);
        Restaurant saved = restaurantRepository.save(restaurant);

        logAction(adminId, "APPROVE_RESTAURANT", "RESTAURANT", restaurantId, null);

        return saved;
    }


    public Restaurant reject(Long restaurantId, Long adminId, String reason) {

        Restaurant restaurant =
            restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new IllegalArgumentException("Restaurant not found."));

        restaurant.setStatus(Restaurant.Status.REJECTED);
        Restaurant saved = restaurantRepository.save(restaurant);

        logAction(adminId, "REJECT_RESTAURANT", "RESTAURANT", restaurantId, reason);

        return saved;
    }


    private void logAction(Long adminId, String action, String targetType, Long targetId, String note) {

        AdminAction record = new AdminAction();
        record.setAdminId(adminId);
        record.setAction(action);
        record.setTargetType(targetType);
        record.setTargetId(targetId);
        record.setNote(note);

        adminActionRepository.save(record);
    }
}
