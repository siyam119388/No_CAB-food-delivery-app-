package com.nocap.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "deliveries")
public class Delivery {

    public enum Status { 
        ASSIGNED, 
        PICKED_UP, 
        DELIVERED, 
        CANCELLED 
    }

    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private Order order;

    @ManyToOne
    @JoinColumn(name = "rider_id")
    private Rider rider;

    @Enumerated(EnumType.STRING)
    private Status status = Status.ASSIGNED;

    @Column(name = "pickup_time")
    private LocalDateTime pickupTime;
    
    @Column(name = "delivery_time")
    private LocalDateTime deliveryTime;
    
    @Column(name = "delivery_fee")
    private Double deliveryFee;
    
    @Column(name = "distance_km")
    private Double distanceKm;

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();
}