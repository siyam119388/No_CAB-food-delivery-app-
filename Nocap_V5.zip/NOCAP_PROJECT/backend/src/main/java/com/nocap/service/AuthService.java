package com.nocap.service;

import com.nocap.model.Rider;
import com.nocap.model.Restaurant;
import com.nocap.model.User;
import com.nocap.repository.RiderRepository;
import com.nocap.repository.RestaurantRepository;
import com.nocap.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RiderRepository riderRepository;

    @Autowired
    private RestaurantRepository restaurantRepository;


    // ============================================================
    // CUSTOMER SIGNUP
    // ============================================================

    public User customerSignup(User user) {

        validateUserData(user);

        checkDuplicateEmail(user.getEmail());

        user.setRole(
            User.Role.CUSTOMER
        );

        return userRepository.save(user);
    }


    // ============================================================
    // RESTAURANT SIGNUP
    // ============================================================

    public User restaurantSignup(
        User user,
        String restaurantName,
        String cuisine,
        String latitude,
        String longitude
    ) {

        validateUserData(user);

        checkDuplicateEmail(user.getEmail());


        // Create restaurant owner account

        user.setRole(
            User.Role.RESTAURANT_OWNER
        );

        User savedUser =
            userRepository.save(user);


        // Create restaurant profile

        Restaurant restaurant =
            new Restaurant();


        restaurant.setOwnerId(
            savedUser.getId()
        );

        restaurant.setAddress(
            user.getAddress()
        );

        if (latitude != null && !latitude.trim().isEmpty()) {
            restaurant.setLatitude(latitude.trim());
        }

        if (longitude != null && !longitude.trim().isEmpty()) {
            restaurant.setLongitude(longitude.trim());
        }


        // Use submitted restaurant name

        if (
            restaurantName != null &&
            !restaurantName.trim().isEmpty()
        ) {

            restaurant.setName(
                restaurantName.trim()
            );

        } else {

            restaurant.setName(
                "New Restaurant"
            );
        }


        // Save cuisine if provided

        if (
            cuisine != null &&
            !cuisine.trim().isEmpty()
        ) {

            restaurant.setCuisine(
                cuisine.trim()
            );
        }


        // New restaurant needs admin approval

        restaurant.setStatus(
            Restaurant.Status.PENDING
        );


        restaurantRepository.save(
            restaurant
        );


        return savedUser;
    }


    // ============================================================
    // ADMIN SIGNUP
    // ============================================================

    public User adminSignup(User user) {

        validateUserData(user);

        checkDuplicateEmail(user.getEmail());


        user.setRole(
            User.Role.ADMIN
        );


        return userRepository.save(user);
    }


    // ============================================================
    // RIDER SIGNUP
    // ============================================================

    public User riderSignup(
        User user,
        String nid
    ) {

        validateUserData(user);

        checkDuplicateEmail(user.getEmail());


        // Create User first

        user.setRole(
            User.Role.RIDER
        );


        User savedUser =
            userRepository.save(user);


        // Create Rider profile

        Rider rider =
            new Rider();


        rider.setUser(
            savedUser
        );


        // NID

        if (
            nid != null &&
            !nid.trim().isEmpty()
        ) {

            rider.setNid(
                nid.trim()
            );

        } else {

            rider.setNid(
                "DEFAULT_NID"
            );
        }


        // Copy user contact information

        rider.setPhone(
            savedUser.getPhone()
        );


        rider.setAddress(
            savedUser.getAddress()
        );


        // New rider requires approval

        rider.setStatus(
            Rider.Status.PENDING
        );


        rider.setIsOnline(
            false
        );


        riderRepository.save(
            rider
        );


        return savedUser;
    }


    // ============================================================
    // LOGIN
    // ============================================================

    public User login(
        String email,
        String password
    ) {

        if (
            email == null ||
            password == null
        ) {

            return null;
        }


        Optional<User> user =
            userRepository.findByEmail(
                email.trim()
            );


        if (
            user.isPresent() &&
            user.get()
                .getPassword()
                .equals(password)
        ) {

            User found = user.get();

            if (
                found.getActive() != null &&
                !found.getActive()
            ) {

                throw new IllegalArgumentException(
                    "This account has been suspended by an admin."
                );
            }

            return found;
        }


        return null;
    }


    // ============================================================
    // GET USER BY ID
    // ============================================================

    public User getUserById(
        Long id
    ) {

        return userRepository
            .findById(id)
            .orElse(null);
    }


    // ============================================================
    // GET RIDER BY USER ID
    // ============================================================

    public Rider getRiderByUserId(
        Long userId
    ) {

        return riderRepository
            .findByUserId(userId)
            .orElse(null);
    }


    // ============================================================
    // GET RESTAURANT BY OWNER ID
    // ============================================================
    //
    // We are intentionally NOT using:
    //
    // restaurantRepository.findByOwnerId(...)
    //
    // because we have not confirmed that such a repository
    // method exists in your current project.
    //
    // This version works with the existing repository's
    // standard findAll() method.
    // ============================================================

    public Restaurant getRestaurantByOwnerId(
        Long ownerId
    ) {

        if (ownerId == null) {

            return null;
        }


        for (
            Restaurant restaurant :
            restaurantRepository.findAll()
        ) {

            if (
                restaurant.getOwnerId() != null &&
                restaurant.getOwnerId()
                    .equals(ownerId)
            ) {

                return restaurant;
            }
        }


        return null;
    }


    // ============================================================
    // VALIDATION
    // ============================================================

    private void validateUserData(
        User user
    ) {

        if (user == null) {

            throw new IllegalArgumentException(
                "User data is required."
            );
        }


        if (
            user.getName() == null ||
            user.getName()
                .trim()
                .isEmpty()
        ) {

            throw new IllegalArgumentException(
                "Name is required."
            );
        }


        if (
            user.getEmail() == null ||
            user.getEmail()
                .trim()
                .isEmpty()
        ) {

            throw new IllegalArgumentException(
                "Email is required."
            );
        }


        if (
            user.getPassword() == null ||
            user.getPassword()
                .isEmpty()
        ) {

            throw new IllegalArgumentException(
                "Password is required."
            );
        }
    }


    // ============================================================
    // DUPLICATE EMAIL CHECK
    // ============================================================

    private void checkDuplicateEmail(
        String email
    ) {

        if (
            email == null ||
            email.trim().isEmpty()
        ) {

            throw new IllegalArgumentException(
                "Email is required."
            );
        }


        if (
            userRepository.existsByEmail(
                email.trim()
            )
        ) {

            throw new IllegalArgumentException(
                "An account already exists with this email."
            );
        }
    }
}