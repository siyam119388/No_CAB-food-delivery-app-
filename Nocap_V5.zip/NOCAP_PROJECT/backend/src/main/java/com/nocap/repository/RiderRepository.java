package com.nocap.repository;

import com.nocap.model.Rider;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.List;

@Repository
public interface RiderRepository extends JpaRepository<Rider, Long> {
    Optional<Rider> findByUserId(Long userId);
    List<Rider> findByStatus(Rider.Status status);
    List<Rider> findByIsOnlineTrue();
}