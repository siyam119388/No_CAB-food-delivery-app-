package com.nocap.controller;

import com.nocap.model.MenuItem;
import com.nocap.repository.MenuItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class MenuItemController {

    @Autowired
    private MenuItemRepository menuItemRepository;

    // ============================================================
    // CUSTOMER MENU  (customer.js -> GET /api/menu?restaurantId=)
    // Only available (in-stock) items.
    // ============================================================
    @GetMapping("/api/menu")
    public ResponseEntity<List<MenuItem>> getMenuForCustomer(@RequestParam Long restaurantId) {
        return ResponseEntity.ok(menuItemRepository.findByRestaurantIdAndAvailableTrue(restaurantId));
    }

    // ============================================================
    // OWNER MENU  (restaurant.js -> GET /api/menu-items/restaurant/{restaurantId})
    // All items including sold-out.
    // ============================================================
    @GetMapping("/api/menu-items/restaurant/{restaurantId}")
    public ResponseEntity<List<MenuItem>> getMenuForOwner(@PathVariable Long restaurantId) {
        return ResponseEntity.ok(menuItemRepository.findByRestaurantId(restaurantId));
    }

    // ============================================================
    // ADD MENU ITEM  (restaurant.js -> POST /api/menu-items)
    // ============================================================
    @PostMapping("/api/menu-items")
    public ResponseEntity<?> addMenuItem(@RequestBody MenuItem item) {

        if (item.getAvailable() == null) {
            item.setAvailable(true);
        }

        return ResponseEntity.ok(menuItemRepository.save(item));
    }

    // ============================================================
    // UPDATE MENU ITEM  (restaurant.js -> PUT /api/menu-items/{id})
    // ============================================================
    @PutMapping("/api/menu-items/{id}")
    public ResponseEntity<?> updateMenuItem(@PathVariable Long id, @RequestBody MenuItem update) {

        return menuItemRepository.findById(id).map(existing -> {

            if (update.getName() != null) existing.setName(update.getName());
            if (update.getDescription() != null) existing.setDescription(update.getDescription());
            if (update.getPrice() != null) existing.setPrice(update.getPrice());
            if (update.getCategory() != null) existing.setCategory(update.getCategory());
            if (update.getAvailable() != null) existing.setAvailable(update.getAvailable());

            return ResponseEntity.ok(menuItemRepository.save(existing));

        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // ============================================================
    // DELETE MENU ITEM  (restaurant.js -> DELETE /api/menu-items/{id})
    // ============================================================
    @DeleteMapping("/api/menu-items/{id}")
    public ResponseEntity<?> deleteMenuItem(@PathVariable Long id) {
        menuItemRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }
}
