package com.nocap.service;

import com.nocap.model.Restaurant;
import com.nocap.repository.RestaurantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RestaurantService {
    
    @Autowired
    private RestaurantRepository restaurantRepository;
    
    // ============================================
    // LOCATION-BASED SEARCH
    // ============================================
    
    /**
     * Get nearby restaurants based on user's latitude/longitude
     * Uses Haversine formula to calculate distance
     */
    public List<Restaurant> getNearbyRestaurants(double userLat, double userLon, double radiusKm) {
        List<Restaurant> allRestaurants = restaurantRepository.findAll();
        
        return allRestaurants.stream()
            .filter(r -> {
                // Only show approved restaurants (FIX: Use enum comparison, not String)
                if (r.getStatus() == null || r.getStatus() != Restaurant.Status.APPROVED) {
                    return false;
                }
                
                // Check if latitude and longitude exist
                if (r.getLatitude() == null || r.getLongitude() == null) {
                    return false;
                }
                
                try {
                    double restLat = Double.parseDouble(r.getLatitude());
                    double restLon = Double.parseDouble(r.getLongitude());
                    double distance = calculateDistance(userLat, userLon, restLat, restLon);
                    return distance <= radiusKm;
                } catch (NumberFormatException e) {
                    return false;
                }
            })
            .sorted((r1, r2) -> {
                try {
                    double restLat1 = Double.parseDouble(r1.getLatitude());
                    double restLon1 = Double.parseDouble(r1.getLongitude());
                    double restLat2 = Double.parseDouble(r2.getLatitude());
                    double restLon2 = Double.parseDouble(r2.getLongitude());
                    
                    double dist1 = calculateDistance(userLat, userLon, restLat1, restLon1);
                    double dist2 = calculateDistance(userLat, userLon, restLat2, restLon2);
                    
                    return Double.compare(dist1, dist2);
                } catch (NumberFormatException e) {
                    return 0;
                }
            })
            .collect(Collectors.toList());
    }
    
    /**
     * Haversine Formula - Calculate distance between two coordinates
     * Returns distance in kilometers
     */
    private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        final int EARTH_RADIUS = 6371; // Radius of the earth in km
        
        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) +
                   Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                   Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        
        return EARTH_RADIUS * c; // Distance in km
    }
    
    // ============================================
    // BASIC RESTAURANT OPERATIONS
    // ============================================
    
    public Restaurant getRestaurantById(Long id) {
        return restaurantRepository.findById(id).orElse(null);
    }
    
    public List<Restaurant> getAllRestaurants() {
        return restaurantRepository.findAll();
    }
    
    public Restaurant saveRestaurant(Restaurant restaurant) {
        return restaurantRepository.save(restaurant);
    }
    
    public void deleteRestaurant(Long id) {
        restaurantRepository.deleteById(id);
    }
}