package com.nocap.service;

import com.nocap.model.Rider;
import com.nocap.model.Delivery;
import com.nocap.model.Order;
import com.nocap.repository.RiderRepository;
import com.nocap.repository.DeliveryRepository;
import com.nocap.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.time.LocalDateTime;

@Service
public class RiderService {

    @Autowired 
    private RiderRepository riderRepository;
    
    @Autowired 
    private DeliveryRepository deliveryRepository;
    
    @Autowired 
    private OrderRepository orderRepository;

    // Toggle online status
    public Rider toggleOnlineStatus(Long riderId) {
        Rider rider = riderRepository.findById(riderId).orElse(null);
        if (rider != null) {
            rider.setIsOnline(!rider.getIsOnline());
            return riderRepository.save(rider);
        }
        return null;
    }

    // Get available deliveries — assigned to nobody yet
    public List<Delivery> getAvailableDeliveries() {
        return deliveryRepository.findByStatusAndRiderIsNull(Delivery.Status.ASSIGNED);
    }

    // Accept delivery — claims it for this rider, but it isn't "picked up"
    // until the rider actually collects the food from the restaurant.
    public Delivery acceptDelivery(Long deliveryId, Long riderId) {
        Delivery delivery = deliveryRepository.findById(deliveryId).orElse(null);
        if (delivery != null && delivery.getStatus() == Delivery.Status.ASSIGNED && delivery.getRider() == null) {
            Rider rider = riderRepository.findById(riderId).orElse(null);
            delivery.setRider(rider);
            return deliveryRepository.save(delivery);
        }
        return null;
    }

    // Mark as picked up
    public Delivery markPickedUp(Long deliveryId) {
        Delivery delivery = deliveryRepository.findById(deliveryId).orElse(null);
        if (delivery != null) {
            delivery.setStatus(Delivery.Status.PICKED_UP);
            delivery.setPickupTime(LocalDateTime.now());
            return deliveryRepository.save(delivery);
        }
        return null;
    }

    // Mark delivered
    public Delivery markDelivered(Long deliveryId) {
        Delivery delivery = deliveryRepository.findById(deliveryId).orElse(null);
        if (delivery != null) {
            delivery.setStatus(Delivery.Status.DELIVERED);
            delivery.setDeliveryTime(LocalDateTime.now());
            
            // Update rider earnings
            Rider rider = delivery.getRider();
            if (rider != null) {
                rider.setTotalEarnings(rider.getTotalEarnings() + delivery.getDeliveryFee());
                rider.setTotalDeliveries(rider.getTotalDeliveries() + 1);
                riderRepository.save(rider);
            }
            
            // Update order status
            Order order = delivery.getOrder();
            order.setStatus(Order.Status.DELIVERED);
            orderRepository.save(order);
            
            return deliveryRepository.save(delivery);
        }
        return null;
    }

    // Get rider deliveries
    public List<Delivery> getRiderDeliveries(Long riderId) {
        return deliveryRepository.findByRiderId(riderId);
    }

    // Get rider profile
    public Rider getRiderProfile(Long riderId) {
        return riderRepository.findById(riderId).orElse(null);
    }

    // Update editable profile fields
    public Rider updateProfile(Long riderId, java.util.Map<String, Object> updates) {
        Rider rider = riderRepository.findById(riderId).orElse(null);
        if (rider == null) {
            return null;
        }
        if (updates.get("phone") != null) {
            rider.setPhone(String.valueOf(updates.get("phone")));
        }
        if (updates.get("address") != null) {
            rider.setAddress(String.valueOf(updates.get("address")));
        }
        return riderRepository.save(rider);
    }

    // Explicitly set online status
    public Rider setOnlineStatus(Long riderId, boolean isOnline) {
        Rider rider = riderRepository.findById(riderId).orElse(null);
        if (rider != null) {
            rider.setIsOnline(isOnline);
            return riderRepository.save(rider);
        }
        return null;
    }

    // Save the rider's latest GPS position
    public Rider updateLocation(Long riderId, String latitude, String longitude) {
        Rider rider = riderRepository.findById(riderId).orElse(null);
        if (rider == null) {
            return null;
        }
        rider.setLatitude(latitude);
        rider.setLongitude(longitude);
        rider.setLocationUpdatedAt(java.time.LocalDateTime.now());
        return riderRepository.save(rider);
    }

    // Get a single delivery by id
    public Delivery getDeliveryById(Long deliveryId) {
        return deliveryRepository.findById(deliveryId).orElse(null);
    }

    // Approve rider (admin action)
    public Rider approveRider(Long riderId) {
        Rider rider = riderRepository.findById(riderId).orElse(null);
        if (rider != null) {
            rider.setStatus(Rider.Status.ACTIVE);
            return riderRepository.save(rider);
        }
        return null;
    }

    // Reject rider (admin action)
    public Rider rejectRider(Long riderId) {
        Rider rider = riderRepository.findById(riderId).orElse(null);
        if (rider != null) {
            rider.setStatus(Rider.Status.REJECTED);
            return riderRepository.save(rider);
        }
        return null;
    }
}