package com.nocap.service;

import com.nocap.model.Delivery;
import com.nocap.model.Order;
import com.nocap.repository.DeliveryRepository;
import com.nocap.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class DeliveryService {

    @Autowired 
    private DeliveryRepository deliveryRepository;
    
    @Autowired 
    private OrderRepository orderRepository;

    // Create delivery when order is placed
    public Delivery createDelivery(Order order, Double deliveryFee) {
        return createDelivery(order, deliveryFee, null);
    }

    public Delivery createDelivery(Order order, Double deliveryFee, Double distanceKm) {
        Delivery delivery = new Delivery();
        delivery.setOrder(order);
        delivery.setDeliveryFee(deliveryFee);
        delivery.setDistanceKm(distanceKm);
        delivery.setStatus(Delivery.Status.ASSIGNED);
        return deliveryRepository.save(delivery);
    }

    // Get delivery by order ID
    public Delivery getDeliveryByOrderId(Long orderId) {
        return deliveryRepository.findByOrderId(orderId).orElse(null);
    }

    // Update delivery status
    public Delivery updateDeliveryStatus(Long deliveryId, Delivery.Status status) {
        Optional<Delivery> delivery = deliveryRepository.findById(deliveryId);
        if (delivery.isPresent()) {
            Delivery d = delivery.get();
            d.setStatus(status);
            return deliveryRepository.save(d);
        }
        return null;
    }

    // Calculate delivery fee (20 TK per km)
    public Double calculateDeliveryFee(Double distanceKm) {
        return distanceKm * 20.0;
    }

    // Get delivery by ID
    public Delivery getDeliveryById(Long deliveryId) {
        return deliveryRepository.findById(deliveryId).orElse(null);
    }
}