package com.nocap.controller;

import com.nocap.model.HygieneCheck;
import com.nocap.model.Order;
import com.nocap.model.Restaurant;
import com.nocap.model.ReviewFlag;
import com.nocap.model.Rider;
import com.nocap.model.User;
import com.nocap.repository.OrderRepository;
import com.nocap.repository.ReviewRepository;
import com.nocap.repository.RiderRepository;
import com.nocap.repository.UserRepository;
import com.nocap.service.HygieneService;
import com.nocap.service.ReviewCheckService;
import com.nocap.service.VerificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* AdminController — base path /api/admin */
@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired
    private VerificationService verificationService;

    @Autowired
    private HygieneService hygieneService;

    @Autowired
    private ReviewCheckService reviewCheckService;

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RiderRepository riderRepository;

    @Autowired
    private OrderRepository orderRepository;


    // ============================================================
    // VERIFICATION
    // ============================================================

    // admin.js -> GET /api/admin/verifications/pending
    @GetMapping("/verifications/pending")
    public ResponseEntity<List<Restaurant>> getPendingVerifications() {
        return ResponseEntity.ok(verificationService.getPendingRestaurants());
    }

    // admin.js -> PUT /api/admin/verify/{restaurantId}
    // body: { adminId, status: "APPROVED" | "REJECTED", rejectionReason? }
    @PutMapping("/verify/{restaurantId}")
    public ResponseEntity<?> verifyRestaurant(@PathVariable Long restaurantId, @RequestBody Map<String, Object> body) {

        try {
            Long adminId = body.get("adminId") != null ? Long.valueOf(String.valueOf(body.get("adminId"))) : null;
            String status = String.valueOf(body.get("status"));

            if ("APPROVED".equalsIgnoreCase(status)) {
                return ResponseEntity.ok(verificationService.approve(restaurantId, adminId));
            }

            String reason = body.get("rejectionReason") != null ? String.valueOf(body.get("rejectionReason")) : null;
            return ResponseEntity.ok(verificationService.reject(restaurantId, adminId, reason));

        } catch (Exception e) {
            return badRequest(e.getMessage());
        }
    }


    // ============================================================
    // HYGIENE MONITORING
    // ============================================================

    // admin.js -> GET /api/admin/hygiene-checks
    @GetMapping("/hygiene-checks")
    public ResponseEntity<List<HygieneCheck>> getAllHygieneChecks() {
        return ResponseEntity.ok(hygieneService.getAllChecks());
    }

    // admin.js -> GET /api/admin/hygiene-checks/restaurant/{restaurantId}
    @GetMapping("/hygiene-checks/restaurant/{restaurantId}")
    public ResponseEntity<List<HygieneCheck>> getRestaurantHygieneChecks(@PathVariable Long restaurantId) {
        return ResponseEntity.ok(hygieneService.getChecksForRestaurant(restaurantId));
    }

    // admin.js -> PUT /api/admin/hygiene-checks/{checkId}/flag
    @PutMapping("/hygiene-checks/{checkId}/flag")
    public ResponseEntity<?> flagHygieneCheck(@PathVariable Long checkId) {
        try {
            return ResponseEntity.ok(hygieneService.flagAsFailed(checkId));
        } catch (Exception e) {
            return badRequest(e.getMessage());
        }
    }


    // ============================================================
    // USER MANAGEMENT
    // ============================================================

    // admin.js -> GET /api/admin/users
    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userRepository.findAll());
    }

    // admin.js -> PUT /api/admin/users/{userId}/suspend
    @PutMapping("/users/{userId}/suspend")
    public ResponseEntity<?> suspendUser(@PathVariable Long userId) {
        return setUserActive(userId, false);
    }

    // admin.js -> PUT /api/admin/users/{userId}/activate
    @PutMapping("/users/{userId}/activate")
    public ResponseEntity<?> activateUser(@PathVariable Long userId) {
        return setUserActive(userId, true);
    }

    private ResponseEntity<?> setUserActive(Long userId, boolean active) {

        User user = userRepository.findById(userId).orElse(null);

        if (user == null) {
            return ResponseEntity.notFound().build();
        }

        user.setActive(active);
        return ResponseEntity.ok(userRepository.save(user));
    }


    // ============================================================
    // REVIEW MANAGEMENT
    // ============================================================

    // admin.js -> GET /api/admin/reviews/flagged
    @GetMapping("/reviews/flagged")
    public ResponseEntity<List<Map<String, Object>>> getFlaggedReviews() {

        List<ReviewFlag> flags = reviewCheckService.getPendingFlags();

        List<Map<String, Object>> result = flags.stream().map(flag -> {

            Map<String, Object> row = new HashMap<>();
            row.put("flagId", flag.getId());
            row.put("confidence", flag.getConfidence());
            row.put("signals", flag.getSignals());

            reviewRepository.findById(flag.getReviewId()).ifPresent(review -> {
                row.put("reviewId", review.getId());
                row.put("rating", review.getRating());
                row.put("comment", review.getComment());
                row.put("restaurantId", review.getRestaurantId());
                row.put("customerId", review.getCustomerId());
            });

            return row;

        }).collect(java.util.stream.Collectors.toList());

        return ResponseEntity.ok(result);
    }

    // admin.js -> DELETE /api/admin/reviews/{reviewId}  (removeReview)
    @DeleteMapping("/reviews/{reviewId}")
    public ResponseEntity<?> removeReview(@PathVariable Long reviewId, @RequestBody(required = false) Map<String, Object> body) {

        try {
            Long adminId = (body != null && body.get("adminId") != null)
                ? Long.valueOf(String.valueOf(body.get("adminId")))
                : null;

            return ResponseEntity.ok(reviewCheckService.removeReview(reviewId, adminId));

        } catch (Exception e) {
            return badRequest(e.getMessage());
        }
    }

    // keep a flagged review visible
    @PutMapping("/reviews/{reviewId}/keep")
    public ResponseEntity<?> keepReview(@PathVariable Long reviewId, @RequestBody(required = false) Map<String, Object> body) {

        try {
            Long adminId = (body != null && body.get("adminId") != null)
                ? Long.valueOf(String.valueOf(body.get("adminId")))
                : null;

            return ResponseEntity.ok(reviewCheckService.keepReview(reviewId, adminId));

        } catch (Exception e) {
            return badRequest(e.getMessage());
        }
    }


    // ============================================================
    // RIDER MANAGEMENT
    // ============================================================

    // admin.js -> GET /api/admin/riders
    @GetMapping("/riders")
    public ResponseEntity<List<Rider>> getAllRiders() {
        return ResponseEntity.ok(riderRepository.findAll());
    }


    // ============================================================
    // ORDERS (for dashboard counts)
    // ============================================================

    // GET /api/admin/orders
    @GetMapping("/orders")
    public ResponseEntity<List<Order>> getAllOrders() {
        return ResponseEntity.ok(orderRepository.findAll());
    }


    private ResponseEntity<?> badRequest(String message) {
        Map<String, String> error = new HashMap<>();
        error.put("error", message != null ? message : "Request failed.");
        return ResponseEntity.badRequest().body(error);
    }
}
