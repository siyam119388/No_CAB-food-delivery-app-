package com.nocap.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "riders")
public class Rider {

    public enum Status { 
        PENDING, 
        APPROVED, 
        REJECTED, 
        ACTIVE, 
        INACTIVE 
    }

    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;

    private String nid;
    
    @Column(name = "nid_photo_url")
    private String nidPhotoUrl;

    @Enumerated(EnumType.STRING)
    private Status status = Status.PENDING;

    private String phone;
    private String address;
    private Double rating = 0.0;
    
    @Column(name = "total_earnings")
    private Double totalEarnings = 0.0;
    
    @Column(name = "total_deliveries")
    private Integer totalDeliveries = 0;
    
    @Column(name = "is_online")
    private Boolean isOnline = false;

    /** Rider's most recent known GPS position (updated from the dashboard while online). */
    private String latitude;
    private String longitude;

    @Column(name = "location_updated_at")
    private LocalDateTime locationUpdatedAt;

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();
}